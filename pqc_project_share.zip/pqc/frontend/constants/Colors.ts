export const Colors = {
  light: {
    text: '#1a1a1a',
    background: '#ffffff',
    tint: '#001F3F',
    tabIconDefault: '#ccc',
    tabIconSelected: '#001F3F',
    primary: '#001F3F', 
    secondary: '#344955',
    success: '#2E7D32',
    error: '#D32F2F',
    surface: '#F5F7FA', // Very light grey for cards/backgrounds
    border: '#E0E0E0',
  },
  dark: {
    text: '#ffffff',
    background: '#0D1117',
    tint: '#58A6FF',
    tabIconDefault: '#ccc',
    tabIconSelected: '#58A6FF',
    primary: '#001F3F', // Keep brand navy? or lighter for dark mode? Let's use lighter blue for dark mode
    secondary: '#344955',
    success: '#2E7D32',
    error: '#D32F2F',
    surface: '#161B22',
    border: '#30363D',
  },
};
