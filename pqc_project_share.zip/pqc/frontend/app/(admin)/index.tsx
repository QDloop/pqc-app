import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';
import { LinearGradient } from 'expo-linear-gradient';

export default function AdminDashboard() {
    const { session, signOut } = useSession();
    const [stats, setStats] = useState({ users: 0, locks: 0, unlocks: 0 });
    const [recentLogs, setRecentLogs] = useState<any[]>([]);
    const [refreshing, setRefreshing] = useState(false);

    const loadData = async () => {
        try {
            const statsData = await api.getStats(session!);
            if (statsData && !statsData.error) {
                setStats({
                    users: statsData.users || 0,
                    locks: statsData.locks || 0,
                    unlocks: statsData.unlocks_today || 0
                });
            }

            const logs = await api.getLogs(session!);
            if (Array.isArray(logs)) {
                setRecentLogs(logs.slice(0, 5)); // Show last 5
            }
        } catch (e) {
            console.error(e);
        } finally {
            setRefreshing(false);
        }
    };

    useEffect(() => {
        loadData();
        const interval = setInterval(() => {
            loadData();
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const onRefresh = () => {
        setRefreshing(true);
        loadData();
    };

    const StatCard = ({ title, value, icon, color }: any) => (
        <View style={[styles.card, { borderLeftColor: color, borderLeftWidth: 4 }]}>
            <View style={styles.cardHeader}>
                <Ionicons name={icon} size={24} color={color} />
                <Text style={styles.cardTitle}>{title}</Text>
            </View>
            <Text style={styles.cardValue}>{value}</Text>
        </View>
    );

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#F8FAFC', '#E2E8F0']} style={styles.background} />
            <ScrollView
                contentContainerStyle={styles.contentContainer}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2563EB" />}
                showsVerticalScrollIndicator={false}
            >
                <View style={[styles.header, { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }]}>
                    <View>
                        <Text style={styles.headerTitle}>Dashboard</Text>
                        <Text style={styles.headerSubtitle}>System Overview & Intelligence</Text>
                    </View>
                    <TouchableOpacity onPress={signOut} style={{ backgroundColor: '#FEE2E2', padding: 8, borderRadius: 20 }}>
                        <Ionicons name="log-out-outline" size={24} color="#EF4444" />
                    </TouchableOpacity>
                </View>

                <View style={styles.statsGrid}>
                    <StatCard title="Total Users" value={stats.users} icon="people" color="#3B82F6" />
                    <StatCard title="Active Locks" value={stats.locks} icon="lock-closed" color="#10B981" />
                    <StatCard title="Today's Unlocks" value={stats.unlocks} icon="key" color="#6366F1" />
                    <StatCard title="Alerts" value="0" icon="warning" color="#EF4444" />
                </View>

                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Recent Activity Stream</Text>
                    <TouchableOpacity>
                        <Text style={styles.seeAll}>See All</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.logsContainer}>
                    {recentLogs.length === 0 ? (
                        <Text style={styles.emptyText}>No recent activity</Text>
                    ) : (
                        recentLogs.map((log, index) => (
                            <View key={index} style={[styles.logItem, index === recentLogs.length - 1 && { borderBottomWidth: 0 }]}>
                                <View style={styles.logIconContainer}>
                                    <Ionicons
                                        name={log.result === 'Success' ? "shield-checkmark" : "warning"}
                                        size={22}
                                        color={log.result === 'Success' ? '#10B981' : '#EF4444'}
                                    />
                                </View>
                                <View style={styles.logContent}>
                                    <Text style={styles.logMessage}>{log.message || log.action || `Access attempt on ${log.lock_id}`}</Text>
                                    <Text style={styles.logTime}>{new Date(log.timestamp).toLocaleString()}</Text>
                                </View>
                            </View>
                        ))
                    )}
                </View>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    background: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    contentContainer: {
        padding: 24,
        paddingTop: 60,
    },
    header: {
        marginBottom: 32,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: '900',
        color: '#1E293B',
        letterSpacing: 0.5,
    },
    headerSubtitle: {
        fontSize: 14,
        color: '#64748B',
        marginTop: 4,
        textTransform: 'uppercase',
    },
    statsGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        marginBottom: 24,
    },
    card: {
        width: '48%',
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        padding: 16,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
    },
    cardHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    cardTitle: {
        fontSize: 13,
        color: '#64748B',
        marginLeft: 8,
        fontWeight: 'bold',
    },
    cardValue: {
        fontSize: 28,
        fontWeight: '900',
        color: '#1E293B',
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
        marginTop: 8,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1E293B',
        letterSpacing: 0.5,
    },
    seeAll: {
        color: '#2563EB',
        fontWeight: 'bold',
        fontSize: 14,
    },
    logsContainer: {
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 20,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.05,
        shadowRadius: 15,
    },
    logItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#F1F5F9',
    },
    logIconContainer: {
        marginRight: 16,
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: '#F8FAFC',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logContent: {
        flex: 1,
    },
    logMessage: {
        fontSize: 14,
        color: '#1E293B',
        fontWeight: '600',
        lineHeight: 20,
    },
    logTime: {
        fontSize: 12,
        color: '#64748B',
        marginTop: 4,
    },
    emptyText: {
        textAlign: 'center',
        color: '#64748B',
        padding: 20,
        fontStyle: 'italic',
    },
});
