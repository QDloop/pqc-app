import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';
import { LinearGradient } from 'expo-linear-gradient';

export default function AuditScreen() {
    const { session } = useSession();
    const [logs, setLogs] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('All'); // All, Success, Failed, Access
    const [sortOrder, setSortOrder] = useState('Newest'); // Newest, Oldest
    const [searchQuery, setSearchQuery] = useState('');

    const fetchLogs = async () => {
        try {
            const data = await api.getLogs(session!);
            if (Array.isArray(data)) {
                setLogs(data);
            } else {
                setLogs([]);
            }
        } catch (e) {
            console.error("Failed to fetch logs", e);
            setLogs([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLogs();
        const interval = setInterval(() => {
            fetchLogs();
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const filteredLogs = logs.filter(log => {
        let passFilter = true;
        if (filter === 'Success') passFilter = log.result === 'Success';
        else if (filter === 'Failed') passFilter = log.result === 'Failed' || log.result === 'Denied' || log.result === 'Error';
        else if (filter === 'Access') passFilter = log.action?.toLowerCase().includes('unlock') || log.action?.toLowerCase().includes('lock');

        if (!passFilter) return false;

        if (searchQuery.trim() !== '') {
            const query = searchQuery.toLowerCase();
            const userName = String(log.user_name || '').toLowerCase();
            const lockName = String(log.lock_name || '').toLowerCase();
            const lockId = String(log.lock_id || '').toLowerCase();
            const message = String(log.message || '').toLowerCase();

            if (!userName.includes(query) && !lockName.includes(query) && !lockId.includes(query) && !message.includes(query)) {
                return false;
            }
        }

        return true;
    }).sort((a, b) => {
        const timeA = new Date(a.timestamp).getTime();
        const timeB = new Date(b.timestamp).getTime();
        return sortOrder === 'Newest' ? timeB - timeA : timeA - timeB;
    });

    const renderLogItem = ({ item }: { item: any }) => {
        const isSuccess = item.result === 'Success';
        return (
            <View style={styles.logCard}>
                <View style={[styles.iconContainer, { backgroundColor: isSuccess ? '#D1FAE5' : '#FEE2E2' }]}>
                    <Ionicons
                        name={isSuccess ? "shield-checkmark" : "warning-outline"}
                        size={24}
                        color={isSuccess ? '#10B981' : '#EF4444'}
                    />
                </View>
                <View style={styles.logContent}>
                    <View style={styles.logHeader}>
                        <Text style={styles.logAction}>{item.action || 'Event'}</Text>
                        <View style={[styles.badge, { backgroundColor: isSuccess ? '#10B981' : '#EF4444' }]}>
                            <Text style={styles.badgeText}>{item.result?.toUpperCase()}</Text>
                        </View>
                    </View>
                    <Text style={styles.logDetails}>{item.message}</Text>
                    <View style={styles.logFooter}>
                        <Text style={styles.logUser}>
                            <Ionicons name="person-outline" size={12} color="#64748B" /> {item.user_name || 'System'}
                        </Text>
                        <Text style={styles.logTime}>{new Date(item.timestamp).toLocaleString()}</Text>
                    </View>
                </View>
            </View>
        );
    };

    if (loading && logs.length === 0) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#2563EB" />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#F8FAFC', '#E2E8F0']} style={styles.background} />

            <View style={styles.header}>
                <View>
                    <Text style={styles.headerTitle}>System Audit Logs</Text>
                    <Text style={styles.headerSubtitle}>Monitor security events & access</Text>
                </View>
                <TouchableOpacity onPress={fetchLogs} style={styles.refreshBtn}>
                    <Ionicons name="refresh" size={20} color="#2563EB" />
                </TouchableOpacity>
            </View>

            <View style={styles.searchContainer}>
                <Ionicons name="search" size={20} color="#94A3B8" style={styles.searchIcon} />
                <TextInput
                    style={styles.searchInput}
                    placeholder="Search users, locks, or events..."
                    placeholderTextColor="#94A3B8"
                    value={searchQuery}
                    onChangeText={setSearchQuery}
                />
                {searchQuery.length > 0 && (
                    <TouchableOpacity onPress={() => setSearchQuery('')}>
                        <Ionicons name="close-circle" size={20} color="#94A3B8" />
                    </TouchableOpacity>
                )}
            </View>

            <View style={styles.controlsContainer}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filtersScroll}>
                    {['All', 'Success', 'Failed', 'Access'].map(f => (
                        <TouchableOpacity
                            key={f}
                            style={[styles.filterChip, filter === f && styles.filterChipActive]}
                            onPress={() => setFilter(f)}
                        >
                            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
                        </TouchableOpacity>
                    ))}
                </ScrollView>
                <TouchableOpacity
                    style={styles.sortBtn}
                    onPress={() => setSortOrder(prev => prev === 'Newest' ? 'Oldest' : 'Newest')}
                >
                    <Ionicons name={sortOrder === 'Newest' ? "arrow-down" : "arrow-up"} size={16} color={sortOrder === 'Newest' ? "#2563EB" : "#64748B"} />
                    <Text style={[styles.sortText, sortOrder === 'Newest' && { color: '#2563EB' }]}>{sortOrder}</Text>
                </TouchableOpacity>
            </View>

            <FlatList
                data={filteredLogs}
                renderItem={renderLogItem}
                keyExtractor={(item, index) => item.id?.toString() || index.toString()}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={<Text style={styles.emptyText}>No logs matching filter.</Text>}
                showsVerticalScrollIndicator={false}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    background: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F8FAFC'
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        paddingHorizontal: 24,
        paddingTop: 60,
        paddingBottom: 20,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: '900',
        color: '#1E293B',
        letterSpacing: 0.5,
    },
    headerSubtitle: {
        fontSize: 14,
        color: '#64748B',
        marginTop: 4,
    },
    refreshBtn: {
        backgroundColor: '#EFF6FF',
        padding: 10,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#BFDBFE',
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        marginHorizontal: 24,
        marginBottom: 16,
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 5,
        elevation: 2,
    },
    searchIcon: {
        marginRight: 10,
    },
    searchInput: {
        flex: 1,
        fontSize: 14,
        color: '#1E293B',
    },
    controlsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 24,
        marginBottom: 16,
    },
    filtersScroll: {
        flexGrow: 0,
        marginRight: 10,
    },
    filterChip: {
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 20,
        backgroundColor: '#FFFFFF',
        marginRight: 8,
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    filterChipActive: {
        backgroundColor: '#2563EB',
        borderColor: '#2563EB',
    },
    filterText: {
        fontSize: 13,
        fontWeight: '600',
        color: '#64748B',
    },
    filterTextActive: {
        color: '#FFFFFF',
    },
    sortBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFFFF',
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    sortText: {
        fontSize: 13,
        fontWeight: 'bold',
        color: '#64748B',
        marginLeft: 4,
    },
    listContent: {
        paddingHorizontal: 24,
        paddingBottom: 40,
    },
    logCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        marginBottom: 16,
        flexDirection: 'row',
        padding: 16,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        elevation: 4,
        shadowColor: '#000',
        shadowOpacity: 0.05,
        shadowRadius: 10,
        shadowOffset: { width: 0, height: 4 },
    },
    iconContainer: {
        width: 48,
        height: 48,
        borderRadius: 24,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16,
    },
    logContent: {
        flex: 1,
    },
    logHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4,
    },
    logAction: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1E293B',
    },
    badge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
    },
    badgeText: {
        color: '#FFFFFF',
        fontSize: 10,
        fontWeight: 'bold',
        letterSpacing: 1,
    },
    logDetails: {
        fontSize: 14,
        color: '#475569',
        marginBottom: 12,
        lineHeight: 20,
    },
    logFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: 12,
        borderTopWidth: 1,
        borderTopColor: '#F1F5F9',
    },
    logUser: {
        fontSize: 12,
        color: '#64748B',
        flexDirection: 'row',
        alignItems: 'center',
    },
    logTime: {
        fontSize: 11,
        color: '#94A3B8',
        fontFamily: 'monospace',
    },
    emptyText: {
        textAlign: 'center',
        marginTop: 40,
        color: '#64748B',
        fontSize: 16,
        fontStyle: 'italic',
    }
});
