import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, Modal, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';

export default function UsersScreen() {
    const { session } = useSession();
    const [users, setUsers] = useState<any[]>([]);
    const [pendingUsers, setPendingUsers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    // Add User Modal State
    const [modalVisible, setModalVisible] = useState(false);
    const [newEmail, setNewEmail] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [newName, setNewName] = useState('');
    const [newRole, setNewRole] = useState('User');
    const [creating, setCreating] = useState(false);

    // Assign Lock Modal State
    const [assignModalVisible, setAssignModalVisible] = useState(false);
    const [selectedUserId, setSelectedUserId] = useState('');
    const [selectedUserName, setSelectedUserName] = useState('');
    const [locks, setLocks] = useState<any[]>([]);
    const [selectedLockId, setSelectedLockId] = useState('');
    const [assigning, setAssigning] = useState(false);

    const loadUsers = async () => {
        try {
            const [usersData, pendingData] = await Promise.all([
                api.getUsers(session!),
                api.getPendingUsers(session!)
            ]);

            if (Array.isArray(usersData)) {
                setUsers(usersData);
            }
            if (Array.isArray(pendingData)) {
                setPendingUsers(pendingData);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadUsers();
        const interval = setInterval(() => {
            loadUsers();
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const handleApprove = async (userId: string) => {
        try {
            await api.approveUser(session!, userId);
            loadUsers();
        } catch (e) {
            Alert.alert("Error", "Failed to approve user");
        }
    };

    const handleDecline = async (userId: string) => {
        Alert.alert("Confirm Decline", "Are you sure you want to decline and delete this signup request?", [
            { text: "Cancel", style: "cancel" },
            {
                text: "Decline", style: "destructive", onPress: async () => {
                    try {
                        await api.declineUser(session!, userId);
                        loadUsers();
                    } catch (e) {
                        Alert.alert("Error", "Failed to decline user");
                    }
                }
            }
        ]);
    };

    const handleCreateUser = async () => {
        if (!newEmail || !newPassword || !newName) {
            Alert.alert("Error", "All fields are required");
            return;
        }
        setCreating(true);
        try {
            const res = await api.registerUser(session!, {
                email: newEmail,
                password: newPassword,
                name: newName,
                role: newRole
            });
            if (res.error) {
                Alert.alert("Error", res.error);
            } else {
                Alert.alert("Success", "User created successfully!");
                setModalVisible(false);
                setNewEmail('');
                setNewPassword('');
                setNewName('');
                setNewRole('User');
                loadUsers();
            }
        } catch (e) {
            Alert.alert("Error", "Network error occurred");
        } finally {
            setCreating(false);
        }
    };

    const openAssignModal = async (user: any) => {
        if (user.role === 'Admin') {
            Alert.alert("Admin Access", "Admins automatically have access to all locks.");
            return;
        }
        setSelectedUserId(user.id);
        setSelectedUserName(user.name);
        setAssignModalVisible(true);
        setSelectedLockId('');

        try {
            const data = await api.getLocks(session!);
            if (Array.isArray(data)) setLocks(data);
        } catch (e) {
            console.error("Failed to load locks");
        }
    };

    const handleAssignPermission = async () => {
        if (!selectedLockId) {
            Alert.alert("Error", "Please select a lock.");
            return;
        }
        setAssigning(true);
        try {
            const res = await api.assignPermission(session!, selectedUserId, selectedLockId);
            if (res.error) {
                Alert.alert("Error", res.error);
            } else {
                Alert.alert("Success", "Permission granted!");
                setAssignModalVisible(false);
            }
        } catch (e) {
            Alert.alert("Error", "Failed to assign permission");
        } finally {
            setAssigning(false);
        }
    };

    const renderItem = ({ item }: { item: any }) => (
        <View style={styles.userCard}>
            <View style={styles.avatarContainer}>
                <Text style={styles.avatarText}>{item.name.charAt(0)}</Text>
            </View>
            <View style={styles.userInfo}>
                <Text style={styles.userName}>{item.name}</Text>
                <Text style={styles.userEmail}>{item.email}</Text>
                <View style={[styles.badge, item.status === 'Active' ? styles.badgeActive : styles.badgeInactive]}>
                    <Text style={[styles.badgeText, item.status === 'Active' ? styles.badgeTextActive : styles.badgeTextInactive]}>
                        {item.role} • {item.status}
                    </Text>
                </View>
            </View>
            {item.role === 'User' && (
                <TouchableOpacity style={styles.assignButton} onPress={() => openAssignModal(item)}>
                    <Ionicons name="key-outline" size={16} color="#2563EB" />
                    <Text style={styles.assignButtonText}>Assign Access</Text>
                </TouchableOpacity>
            )}
        </View>
    );

    return (
        <View style={styles.container}>
            {loading ? (
                <ActivityIndicator size="large" color={Colors.light.primary} style={{ marginTop: 50 }} />
            ) : (
                <FlatList
                    data={users}
                    renderItem={renderItem}
                    keyExtractor={item => item.id}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    ListHeaderComponent={
                        <View>
                            <View style={styles.header}>
                                <Text style={styles.headerTitle}>Users</Text>
                                <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
                                    <Ionicons name="person-add" size={20} color="#FFF" />
                                    <Text style={styles.addButtonText}>Add User</Text>
                                </TouchableOpacity>
                            </View>

                            {pendingUsers.length > 0 && (
                                <View style={styles.pendingSection}>
                                    <Text style={styles.pendingSectionTitle}>Action Required: Pending Approvals</Text>
                                    {pendingUsers.map(user => (
                                        <View key={`pending-${user.id}`} style={styles.pendingCard}>
                                            <View style={styles.pendingInfo}>
                                                <Text style={styles.pendingName}>{user.name}</Text>
                                                <Text style={styles.pendingEmail}>{user.email}</Text>
                                                <Text style={styles.pendingRole}>Requested Role: {user.role}</Text>
                                            </View>
                                            <View style={styles.pendingActions}>
                                                <TouchableOpacity style={styles.actionBtnAccept} onPress={() => handleApprove(user.id)}>
                                                    <Ionicons name="checkmark" size={20} color="#FFF" />
                                                </TouchableOpacity>
                                                <TouchableOpacity style={styles.actionBtnDecline} onPress={() => handleDecline(user.id)}>
                                                    <Ionicons name="close" size={20} color="#FFF" />
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                    ))}
                                    <Text style={styles.sectionDividerText}>Verified Personnel</Text>
                                </View>
                            )}
                        </View>
                    }
                    ListEmptyComponent={<Text style={{ textAlign: 'center', marginTop: 20, color: '#999' }}>No users found</Text>}
                />
            )}

            {/* Add User Modal */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="person-add" size={28} color="#2563EB" />
                            <Text style={styles.modalTitle}>New Employee</Text>
                        </View>

                        <Text style={styles.inputLabel}>Full Name</Text>
                        <TextInput style={styles.input} placeholder="John Doe" value={newName} onChangeText={setNewName} />

                        <Text style={styles.inputLabel}>Email Address</Text>
                        <TextInput style={styles.input} placeholder="john@example.com" value={newEmail} onChangeText={setNewEmail} keyboardType="email-address" />

                        <Text style={styles.inputLabel}>Secure Password</Text>
                        <TextInput style={styles.input} placeholder="Enter temporary password" value={newPassword} onChangeText={setNewPassword} secureTextEntry />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.cancelBtn} onPress={() => setModalVisible(false)}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.confirmBtn} onPress={handleCreateUser} disabled={creating}>
                                {creating ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.confirmText}>Create User</Text>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* Assign Lock Modal */}
            <Modal visible={assignModalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="key" size={28} color="#2563EB" />
                            <Text style={styles.modalTitle}>Grant Access</Text>
                        </View>
                        <Text style={{ marginBottom: 20, color: '#64748B' }}>
                            Select a door to grant unlock privileges to <Text style={{ fontWeight: 'bold', color: '#1E293B' }}>{selectedUserName}</Text>.
                        </Text>

                        <Text style={styles.inputLabel}>Available Locks</Text>
                        <FlatList
                            data={locks}
                            keyExtractor={i => i.id}
                            style={{ maxHeight: 200, marginBottom: 20 }}
                            renderItem={({ item }) => (
                                <TouchableOpacity
                                    style={[styles.lockSelectItem, selectedLockId === item.id && styles.lockSelectItemSelected]}
                                    onPress={() => setSelectedLockId(item.id)}
                                >
                                    <Ionicons name="lock-closed" size={20} color={selectedLockId === item.id ? "#2563EB" : "#94A3B8"} />
                                    <View style={{ marginLeft: 12 }}>
                                        <Text style={[styles.lockSelectName, selectedLockId === item.id && { color: '#2563EB' }]}>{item.name}</Text>
                                        <Text style={styles.lockSelectId}>ID: {item.id}</Text>
                                    </View>
                                </TouchableOpacity>
                            )}
                            ListEmptyComponent={<Text style={{ textAlign: 'center', margin: 10, color: '#94A3B8' }}>No approved locks available</Text>}
                        />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.cancelBtn} onPress={() => setAssignModalVisible(false)}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.confirmBtn} onPress={handleAssignPermission} disabled={assigning}>
                                {assigning ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.confirmText}>Grant Access</Text>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FA',
    },
    listContent: {
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.light.primary,
    },
    addButton: {
        backgroundColor: Colors.light.primary,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: 20,
        elevation: 2,
    },
    addButtonText: {
        color: '#FFF',
        fontWeight: 'bold',
        marginLeft: 8,
    },
    sectionDividerText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1E293B',
        marginTop: 24,
        marginBottom: 8,
        paddingLeft: 4,
    },
    pendingSection: {
        marginBottom: 16,
    },
    pendingSectionTitle: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#EF4444',
        textTransform: 'uppercase',
        marginBottom: 12,
        paddingLeft: 4,
        letterSpacing: 0.5,
    },
    pendingCard: {
        backgroundColor: '#FEF2F2',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderWidth: 1,
        borderColor: '#FECACA',
    },
    pendingInfo: {
        flex: 1,
    },
    pendingName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#991B1B',
    },
    pendingEmail: {
        fontSize: 14,
        color: '#B91C1C',
        marginBottom: 4,
    },
    pendingRole: {
        fontSize: 12,
        color: '#DC2626',
        fontWeight: 'bold',
    },
    pendingActions: {
        flexDirection: 'row',
        gap: 8,
    },
    actionBtnAccept: {
        backgroundColor: '#10B981',
        padding: 8,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionBtnDecline: {
        backgroundColor: '#EF4444',
        padding: 8,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
    },
    userCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        flexDirection: 'row',
        alignItems: 'center',
        elevation: 1,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
    },
    avatarContainer: {
        width: 50,
        height: 50,
        borderRadius: 25,
        backgroundColor: Colors.light.primary,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16,
    },
    avatarText: {
        color: '#FFF',
        fontSize: 20,
        fontWeight: 'bold',
    },
    userInfo: {
        flex: 1,
    },
    userName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    userEmail: {
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
    },
    badge: {
        alignSelf: 'flex-start',
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 10,
    },
    badgeActive: {
        backgroundColor: '#E8F5E9',
    },
    badgeInactive: {
        backgroundColor: '#FFEBEE',
    },
    badgeText: {
        fontSize: 10,
        fontWeight: 'bold',
    },
    badgeTextActive: {
        color: '#2E7D32',
    },
    badgeTextInactive: {
        color: '#D32F2F',
    },
    moreButton: {
        padding: 8,
    },
    assignButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#EFF6FF',
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#BFDBFE',
    },
    assignButtonText: {
        color: '#2563EB',
        fontWeight: 'bold',
        fontSize: 12,
        marginLeft: 6,
    },

    // Modals
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 24 },
    modalContent: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.1, shadowRadius: 20, elevation: 10 },
    modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 24 },
    modalTitle: { fontSize: 22, fontWeight: 'bold', color: '#1E293B', marginLeft: 12 },
    inputLabel: { fontSize: 12, fontWeight: 'bold', color: '#64748B', marginBottom: 8, textTransform: 'uppercase' },
    input: {
        borderWidth: 1,
        borderColor: '#E2E8F0',
        borderRadius: 12,
        padding: 16,
        fontSize: 16,
        marginBottom: 20,
        backgroundColor: '#F8FAFC',
        color: '#1E293B'
    },
    modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', marginTop: 8 },
    cancelBtn: { paddingHorizontal: 20, paddingVertical: 12, marginRight: 8 },
    cancelText: { color: '#64748B', fontWeight: 'bold', fontSize: 16 },
    confirmBtn: { backgroundColor: '#2563EB', paddingHorizontal: 24, paddingVertical: 14, borderRadius: 12, minWidth: 120, alignItems: 'center' },
    confirmText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },

    lockSelectItem: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        borderWidth: 1,
        borderColor: '#E2E8F0',
        borderRadius: 12,
        marginBottom: 8,
        backgroundColor: '#F8FAFC'
    },
    lockSelectItemSelected: {
        borderColor: '#2563EB',
        backgroundColor: '#EFF6FF',
    },
    lockSelectName: {
        fontWeight: 'bold',
        color: '#1E293B',
        fontSize: 16,
    },
    lockSelectId: {
        fontSize: 12,
        color: '#64748B',
    }
});
