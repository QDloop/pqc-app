import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, Alert, Modal, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';

export default function LocksManagement() {
    const { session } = useSession();
    const [locks, setLocks] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    // Unlock Modal State
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedLock, setSelectedLock] = useState<any>(null);
    const [password, setPassword] = useState('');
    const [unlocking, setUnlocking] = useState(false);

    // Add Lock Modal State
    const [addModalVisible, setAddModalVisible] = useState(false);
    const [newLockId, setNewLockId] = useState('');
    const [newLockName, setNewLockName] = useState('');
    const [newLockToken, setNewLockToken] = useState('');
    const [adding, setAdding] = useState(false);

    const fetchLocks = async () => {
        try {
            const data = await api.getLocks(session!);
            if (Array.isArray(data)) {
                setLocks(data);
            } else if (data && data.error) {
                console.error(data.error);
                setLocks([]);
            } else {
                setLocks([]);
            }
        } catch (e) {
            console.error("Failed to fetch locks", e);
            setLocks([]);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        fetchLocks();
        const interval = setInterval(() => {
            fetchLocks();
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const onRefresh = () => {
        setRefreshing(true);
        fetchLocks();
    };

    const handleAddLock = () => {
        setAddModalVisible(true);
    };

    const confirmAddLock = async () => {
        if (!newLockId || !newLockName || !newLockToken) {
            Alert.alert("Error", "All fields are required");
            return;
        }
        setAdding(true);
        try {
            const res = await api.registerLock({
                device_id: newLockId,
                name: newLockName,
                token: newLockToken
            });
            if (res.error) {
                Alert.alert("Error", res.error);
            } else {
                Alert.alert("Success", "Lock registered successfully!");
                setAddModalVisible(false);
                setNewLockId('');
                setNewLockName('');
                setNewLockToken('');
                fetchLocks();
            }
        } catch (e) {
            Alert.alert("Error", "Network error occurred");
        } finally {
            setAdding(false);
        }
    };

    const approvePendingLock = async (lockId: string) => {
        try {
            const res = await api.approveLock(session!, lockId);
            if (res.error) {
                Alert.alert("Error", res.error);
            } else {
                Alert.alert("Approved", "Lock has been approved and activated.");
                fetchLocks();
            }
        } catch (e) {
            Alert.alert("Error", "Could not approve lock");
        }
    };

    const handleUnlockRequest = (lock: any) => {
        setSelectedLock(lock);
        setModalVisible(true);
    };

    const confirmUnlock = async () => {
        setUnlocking(true);
        try {
            const res = await api.unlock(session!, selectedLock.id, password);
            setModalVisible(false);
            setPassword('');
            if (res.error) {
                Alert.alert("Unlock Failed", res.error);
            } else {
                Alert.alert("Success", "Device Unlocked Successfully");
                fetchLocks();
            }
        } catch (e) {
            Alert.alert("Error", "Network request failed");
        } finally {
            setUnlocking(false);
        }
    };

    const handleRelock = async (lockId: string) => {
        try {
            const res = await api.relock(session!, lockId);
            if (res.error) {
                Alert.alert("Relock Failed", res.error);
            } else {
                Alert.alert("Success", "Device Relocked Successfully");
                fetchLocks();
            }
        } catch (e) {
            Alert.alert("Error", "Network request failed");
        }
    };

    const LockItem = ({ item }: { item: any }) => {
        const isLocked = item.status === 'Locked';
        const isApproved = item.approved === 1;

        return (
            <View style={styles.card}>
                <View style={styles.cardHeader}>
                    <View style={[styles.iconContainer, { backgroundColor: isLocked ? '#FEE2E2' : '#D1FAE5' }]}>
                        <Ionicons
                            name={isLocked ? "lock-closed" : "lock-open"}
                            size={24}
                            color={isLocked ? '#EF4444' : '#10B981'}
                        />
                    </View>
                    <View style={styles.headerText}>
                        <Text style={styles.lockName}>{item.name}</Text>
                        <Text style={styles.lockId}>ID: {item.id}</Text>
                        <Text style={styles.lockType}>{item.type || 'Standard Lock'}</Text>
                    </View>
                </View>

                <View style={styles.statusContainer}>
                    <View style={[styles.statusBadge, { backgroundColor: isApproved ? (isLocked ? '#EF4444' : '#10B981') : '#F59E0B' }]}>
                        <Text style={[styles.statusText, { color: '#FFFFFF' }]}>
                            {isApproved ? item.status.toUpperCase() : 'PENDING APPROVAL'}
                        </Text>
                    </View>
                    <Text style={styles.lastSync}>Updated Just Now</Text>
                </View>

                {!isApproved ? (
                    <TouchableOpacity
                        style={[styles.unlockButton, { backgroundColor: '#F59E0B', shadowColor: '#F59E0B' }]}
                        onPress={() => approvePendingLock(item.id)}
                    >
                        <Ionicons name="checkmark-circle-outline" size={22} color="#FFFFFF" style={{ marginRight: 8 }} />
                        <Text style={styles.unlockButtonText}>APPROVE LOCK</Text>
                    </TouchableOpacity>
                ) : (
                    <TouchableOpacity
                        style={[styles.unlockButton, !isLocked && { backgroundColor: '#EF4444', shadowColor: '#EF4444' }]}
                        onPress={() => isLocked ? handleUnlockRequest(item) : handleRelock(item.id)}
                    >
                        <Ionicons name={isLocked ? "key-outline" : "lock-closed-outline"} size={22} color="#FFFFFF" style={{ marginRight: 8 }} />
                        <Text style={styles.unlockButtonText}>{isLocked ? "UNLOCK DEVICE" : "RELOCK DEVICE"}</Text>
                    </TouchableOpacity>
                )}
            </View>
        );
    };

    if (loading) {
        return (
            <View style={[styles.container, styles.center]}>
                <ActivityIndicator size="large" color={Colors.light.primary} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <View>
                    <Text style={styles.headerTitle}>Locks</Text>
                    <Text style={styles.headerSubtitle}>Manage access points</Text>
                </View>
                <TouchableOpacity style={styles.addButton} onPress={handleAddLock}>
                    <Ionicons name="add" size={24} color="#FFF" />
                </TouchableOpacity>
            </View>

            <FlatList
                data={locks}
                renderItem={({ item }) => <LockItem item={item} />}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContent}
                refreshing={refreshing}
                onRefresh={onRefresh}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Ionicons name="lock-closed-outline" size={48} color="#CCC" />
                        <Text style={styles.emptyText}>No locks found</Text>
                    </View>
                }
            />

            {/* Password Verification Modal */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="shield-checkmark" size={32} color="#2563EB" />
                            <Text style={styles.modalTitle}>Security Check</Text>
                        </View>
                        <Text style={styles.modalSubtitle}>Device selected. Enter admin password to authorize unlock.</Text>

                        <Text style={styles.inputLabel}>Admin Verification</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Enter your secure password"
                            secureTextEntry
                            value={password}
                            onChangeText={setPassword}
                            autoFocus
                        />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setModalVisible(false); setPassword(''); }}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.confirmBtn} onPress={confirmUnlock} disabled={unlocking}>
                                {unlocking ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.confirmText}>Unlock Device</Text>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* Add Lock Modal */}
            <Modal visible={addModalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="add-circle" size={32} color="#2563EB" />
                            <Text style={styles.modalTitle}>Register Hardware Lock</Text>
                        </View>

                        <Text style={styles.inputLabel}>Device ID</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="e.g. lock3"
                            value={newLockId}
                            onChangeText={setNewLockId}
                            autoCapitalize="none"
                        />

                        <Text style={styles.inputLabel}>Lock Name</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="e.g. Back Door"
                            value={newLockName}
                            onChangeText={setNewLockName}
                        />

                        <Text style={styles.inputLabel}>Secret Token</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Shared hardware secret token"
                            value={newLockToken}
                            onChangeText={setNewLockToken}
                            secureTextEntry
                        />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setAddModalVisible(false); }}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.confirmBtn} onPress={confirmAddLock} disabled={adding}>
                                {adding ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.confirmText}>Register</Text>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FA',
    },
    center: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingTop: 20,
        paddingBottom: 10,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: Colors.light.primary,
    },
    headerSubtitle: {
        fontSize: 14,
        color: Colors.light.secondary,
    },
    addButton: {
        backgroundColor: Colors.light.primary,
        width: 44,
        height: 44,
        borderRadius: 22,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
    },
    listContent: {
        padding: 20,
    },
    card: {
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 24,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.05,
        shadowRadius: 20,
        elevation: 5,
    },
    cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
    iconContainer: { width: 56, height: 56, borderRadius: 28, justifyContent: 'center', alignItems: 'center', marginRight: 16, borderWidth: 1, borderColor: '#F1F5F9' },
    headerText: { flex: 1 },
    lockName: { fontSize: 20, fontWeight: 'bold', color: '#1E293B', marginBottom: 4 },
    lockId: { fontSize: 13, color: '#64748B', fontFamily: 'monospace' },
    lockType: { fontSize: 12, color: '#2563EB', marginTop: 4, fontWeight: '700', textTransform: 'uppercase' },
    statusContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, backgroundColor: '#F8FAFC', padding: 12, borderRadius: 12 },
    statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
    statusText: { fontSize: 12, fontWeight: 'bold', letterSpacing: 1 },
    lastSync: { fontSize: 12, color: '#94A3B8', fontStyle: 'italic' },
    unlockButton: {
        backgroundColor: '#2563EB',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 18,
        borderRadius: 16,
        shadowColor: '#2563EB',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.3,
        shadowRadius: 12,
        elevation: 4,
    },
    unlockButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', letterSpacing: 0.5 },
    emptyContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 60,
    },
    emptyText: {
        marginTop: 16,
        fontSize: 16,
        color: '#999',
    },
    // Modals
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 24 },
    modalContent: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.1, shadowRadius: 20, elevation: 10 },
    modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
    modalTitle: { fontSize: 22, fontWeight: 'bold', color: '#1E293B', marginLeft: 12 },
    modalSubtitle: { fontSize: 14, color: '#64748B', marginBottom: 24, lineHeight: 22 },
    inputLabel: { fontSize: 12, fontWeight: 'bold', color: '#2563EB', marginBottom: 8, textTransform: 'uppercase' },
    input: {
        borderWidth: 1,
        borderColor: '#E2E8F0',
        borderRadius: 12,
        padding: 18,
        fontSize: 16,
        marginBottom: 24,
        backgroundColor: '#F8FAFC',
        color: '#1E293B'
    },
    modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' },
    cancelBtn: { paddingHorizontal: 20, paddingVertical: 12, marginRight: 8 },
    cancelText: { color: '#64748B', fontWeight: 'bold', fontSize: 16 },
    confirmBtn: { backgroundColor: '#2563EB', paddingHorizontal: 24, paddingVertical: 14, borderRadius: 12, minWidth: 120, alignItems: 'center' },
    confirmText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
});
