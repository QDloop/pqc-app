import React, { useState, useEffect } from 'react';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { Tabs } from 'expo-router';
import { Colors } from '../../constants/Colors';
import { api } from '../../services/api';
import { useSession } from '../../context/auth';

function TabBarIcon(props: {
    name: React.ComponentProps<typeof FontAwesome>['name'];
    color: string;
}) {
    return <FontAwesome size={28} style={{ marginBottom: -3 }} {...props} />;
}

export default function AdminLayout() {
    const { session } = useSession();
    const [unread, setUnread] = useState(0);

    useEffect(() => {
        if (!session) return;
        const fetchUnread = async () => {
            try {
                const data = await api.getUnreadCount(session);
                if (data && typeof data.unread === 'number') setUnread(data.unread);
            } catch (e) { }
        };
        fetchUnread();
        const interval = setInterval(fetchUnread, 5000);
        return () => clearInterval(interval);
    }, [session]);

    return (
        <Tabs
            screenOptions={{
                tabBarActiveTintColor: '#2563EB',
                tabBarInactiveTintColor: '#64748B',
                headerShown: false,
                tabBarHideOnKeyboard: true,
                tabBarStyle: {
                    backgroundColor: '#FFFFFF',
                    borderTopColor: '#E2E8F0',
                    borderTopWidth: 1,
                    paddingBottom: 5,
                    height: 60
                }
            }}>
            <Tabs.Screen
                name="index"
                options={{
                    title: 'Overview',
                    tabBarIcon: ({ color }) => <TabBarIcon name="dashboard" color={color} />,
                }}
            />
            <Tabs.Screen
                name="users"
                options={{
                    title: 'Users',
                    tabBarIcon: ({ color }) => <TabBarIcon name="users" color={color} />,
                }}
            />
            <Tabs.Screen
                name="locks"
                options={{
                    title: 'Locks',
                    tabBarIcon: ({ color }) => <TabBarIcon name="unlock-alt" color={color} />,
                }}
            />
            <Tabs.Screen
                name="audit"
                options={{
                    title: 'Audit',
                    tabBarIcon: ({ color }) => <TabBarIcon name="list-alt" color={color} />,
                }}
            />
            <Tabs.Screen
                name="chat"
                options={{
                    title: 'Chat',
                    tabBarIcon: ({ color }) => <TabBarIcon name="comments" color={color} />,
                    tabBarBadge: unread > 0 ? unread : undefined
                }}
            />
        </Tabs>
    );
}
