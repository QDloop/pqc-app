import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, SafeAreaView, StatusBar, TouchableOpacity, Modal, ScrollView } from 'react-native';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';
import { LinearGradient } from 'expo-linear-gradient';

export default function LockStatusScreen() {
    const { session, signOut } = useSession();
    const [status, setStatus] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
    const [infoVisible, setInfoVisible] = useState(false);

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date().toLocaleTimeString());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            fetchStatus();
        }, 3000);

        fetchStatus();

        return () => clearInterval(interval);
    }, []);

    const fetchStatus = async () => {
        try {
            const data = await api.getLockStatus(session!);
            if (!data.error) {
                setStatus(data);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    if (loading && !status) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={Colors.light.primary} />
                <Text style={styles.loadingText}>Initializing Secure Module...</Text>
            </View>
        );
    }

    const isLocked = status?.status === 'Locked';

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#F8FAFC" />
            <LinearGradient colors={['#F8FAFC', '#E2E8F0']} style={styles.background} />

            <View style={styles.header}>
                <View>
                    <Text style={styles.deviceLabel}>QUANTUM ID MODULE</Text>
                    <Text style={styles.deviceId}>{status?.id || 'LCK-8821-X'}</Text>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <View style={styles.connectionBadge}>
                        <View style={styles.activeDot} />
                        <Text style={styles.connectionText}>ONLINE</Text>
                    </View>
                    <TouchableOpacity onPress={signOut} style={{ marginLeft: 16, backgroundColor: '#FEE2E2', padding: 8, borderRadius: 20 }}>
                        <Ionicons name="log-out-outline" size={20} color="#EF4444" />
                    </TouchableOpacity>
                </View>
            </View>

            <View style={styles.mainContent}>
                <View style={[styles.statusCard, { borderColor: isLocked ? '#FECACA' : '#A7F3D0' }]}>
                    <View style={[styles.iconContainer, { backgroundColor: isLocked ? '#FEE2E2' : '#D1FAE5', borderColor: isLocked ? '#FECACA' : '#A7F3D0' }]}>
                        <FontAwesome
                            name={isLocked ? "lock" : "unlock"}
                            size={64}
                            color={isLocked ? '#EF4444' : '#10B981'}
                        />
                    </View>
                    <Text style={styles.statusTitle}>Module Security State</Text>
                    <Text style={[styles.statusText, { color: isLocked ? '#EF4444' : '#10B981' }]}>
                        {isLocked ? "LOCKED & SECURE" : "UNLOCKED"}
                    </Text>
                    <Text style={styles.lastSync}>Last Handshake: {currentTime}</Text>
                </View>

                <View style={styles.terminalContainer}>
                    <View style={styles.terminalHeader}>
                        <Ionicons name="shield-checkmark" size={16} color="#2563EB" />
                        <Text style={styles.terminalTitle}>SECURE KEY-STREAM LOGS</Text>
                    </View>
                    <View style={styles.terminalContent}>
                        {status?.status === 'Unlocked' ? (
                            <>
                                <Text style={styles.logLine}>
                                    <Text style={styles.logTime}>[{currentTime}]</Text> PQC KEM AUTH <Text style={[styles.logOk, { color: '#10B981' }]}>SUCCESS</Text>
                                </Text>
                                <Text style={styles.logLine}>
                                    <Text style={styles.logTime}>[{currentTime}]</Text> UNLOCKED BY SIGNAL:
                                </Text>
                                <Text style={[styles.logLine, { color: '#2563EB', fontWeight: 'bold' }]}>
                                    {'>>'} {status?.last_unlocked_by || 'Verified Token'}
                                </Text>
                            </>
                        ) : (
                            <>
                                <Text style={styles.logLine}>
                                    <Text style={styles.logTime}>[{currentTime}]</Text> AES-GCM Subsystem <Text style={styles.logOk}>ACTIVE</Text>
                                </Text>
                                <Text style={styles.logLine}>
                                    <Text style={styles.logTime}>[{currentTime}]</Text> ML-KEM-512 Node <Text style={styles.logOk}>STANDBY</Text>
                                </Text>
                                <Text style={styles.logLine}>
                                    <Text style={styles.logTime}>[{currentTime}]</Text> Listening for authorized bursts...
                                </Text>
                            </>
                        )}
                        <View style={styles.cursorBlock} />
                    </View>
                </View>
            </View>

            <View style={styles.footer}>
                <TouchableOpacity onPress={() => setInfoVisible(true)} style={styles.footerButton}>
                    <Ionicons name="shield-checkmark" size={16} color="#2563EB" />
                    <Text style={[styles.footerText, { color: '#2563EB', marginLeft: 8, fontWeight: 'bold' }]}>PQC ACTIVE (Learn More)</Text>
                </TouchableOpacity>
                <Text style={styles.footerVersion}>QuantumLock Core v2.0.0</Text>
            </View>

            {/* PQC Info Modal */}
            <Modal visible={infoVisible} transparent animationType="slide" onRequestClose={() => setInfoVisible(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="shield-half" size={32} color="#2563EB" />
                            <Text style={styles.modalTitle}>Post-Quantum Security</Text>
                        </View>
                        <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
                            <Text style={styles.infoHeading}>How It Works</Text>
                            <Text style={styles.infoText}>
                                Our system is secured by CRYSTALS-Kyber (ML-KEM-512), a lattice-based key encapsulation mechanism. When a user requests an unlock, the backend and the application simulate a secure post-quantum key exchange to challenge and verify the authentication strictly over secure channels.
                            </Text>

                            <Text style={styles.infoHeading}>Why It's Safe</Text>
                            <Text style={styles.infoText}>
                                Traditional encryption (like RSA) relies on factoring prime numbers—a problem quantum computers will easily solve using Shor's Algorithm.
                                Kyber's security rests on the hardness of the Module Learning With Errors (MLWE) problem over mathematical lattices. There are no known efficient quantum algorithms capable of breaking this underlying lattice structure, keeping your locks eternally safe against future quantum attacks!
                            </Text>

                            <Text style={styles.infoHeading}>NIST Standardized</Text>
                            <Text style={styles.infoText}>
                                Kyber has been officially standardized by the National Institute of Standards and Technology (NIST) as the primary post-quantum key agreement protocol, meaning you are backed by globally reviewed and trusted cryptographic science.
                            </Text>
                        </ScrollView>
                        <TouchableOpacity style={styles.closeBtn} onPress={() => setInfoVisible(false)}>
                            <Text style={styles.closeBtnText}>Initialize Secure Orbit</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    background: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F8FAFC',
    },
    loadingText: {
        marginTop: 16,
        color: '#2563EB',
        fontSize: 16,
        letterSpacing: 2,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 24,
        marginBottom: 32,
    },
    deviceLabel: {
        fontSize: 12,
        fontWeight: 'bold',
        color: '#64748B',
        letterSpacing: 1.5,
    },
    deviceId: {
        fontSize: 18,
        fontWeight: '900',
        color: '#1E293B',
        fontFamily: 'monospace',
    },
    connectionBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#EFF6FF',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#BFDBFE',
    },
    activeDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#10B981',
        marginRight: 8,
        shadowColor: '#10B981',
        shadowOffset: { width: 0, height: 0 },
        shadowOpacity: 0.5,
        shadowRadius: 5,
    },
    connectionText: {
        fontSize: 12,
        fontWeight: 'bold',
        color: '#2563EB',
        letterSpacing: 1,
    },
    mainContent: {
        flex: 1,
        paddingHorizontal: 24,
    },
    statusCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 40,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.05,
        shadowRadius: 20,
        elevation: 5,
        marginBottom: 32,
        borderWidth: 1,
    },
    iconContainer: {
        width: 120,
        height: 120,
        borderRadius: 60,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 24,
        borderWidth: 1,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    statusTitle: {
        fontSize: 14,
        color: '#64748B',
        marginBottom: 8,
        textTransform: 'uppercase',
        letterSpacing: 2,
        fontWeight: 'bold',
    },
    statusText: {
        fontSize: 32,
        fontWeight: '900',
        letterSpacing: 1.5,
        marginBottom: 16,
    },
    lastSync: {
        fontSize: 12,
        color: '#94A3B8',
        fontFamily: 'monospace',
    },
    terminalContainer: {
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: '#F1F5F9',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.05,
        shadowRadius: 15,
        elevation: 4,
    },
    terminalHeader: {
        backgroundColor: '#F8FAFC',
        paddingHorizontal: 16,
        paddingVertical: 12,
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderBottomColor: '#E2E8F0',
    },
    terminalTitle: {
        color: '#1E293B',
        fontSize: 12,
        fontFamily: 'monospace',
        marginLeft: 8,
        fontWeight: 'bold',
        letterSpacing: 1,
    },
    terminalContent: {
        padding: 16,
        minHeight: 140,
    },
    logLine: {
        color: '#475569',
        fontFamily: 'monospace',
        fontSize: 12,
        marginBottom: 6,
    },
    logTime: {
        color: '#94A3B8',
    },
    logOk: {
        color: '#10B981',
        fontWeight: 'bold',
    },
    cursorBlock: {
        width: 10,
        height: 14,
        backgroundColor: '#2563EB',
        marginTop: 4,
        opacity: 0.8,
    },
    footer: {
        padding: 24,
        alignItems: 'center',
        paddingBottom: 40,
    },
    footerButton: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 10,
        backgroundColor: '#EFF6FF',
        borderRadius: 20,
        marginBottom: 16,
        borderWidth: 1,
        borderColor: '#BFDBFE',
    },
    footerText: {
        fontSize: 11,
        color: '#64748B',
        letterSpacing: 1,
        marginTop: 4,
    },
    footerVersion: {
        fontSize: 10,
        color: '#94A3B8',
        letterSpacing: 1,
    },
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 24 },
    modalContent: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, elevation: 5, maxHeight: '80%', shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.1, shadowRadius: 20 },
    modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
    modalTitle: { fontSize: 22, fontWeight: 'bold', color: '#1E293B', marginLeft: 12 },
    modalScroll: { marginBottom: 20 },
    infoHeading: { fontSize: 16, fontWeight: 'bold', color: '#2563EB', marginTop: 12, marginBottom: 8, letterSpacing: 1 },
    infoText: { fontSize: 14, color: '#475569', lineHeight: 24 },
    closeBtn: { backgroundColor: '#2563EB', paddingVertical: 16, borderRadius: 16, alignItems: 'center', marginTop: 16 },
    closeBtnText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16, letterSpacing: 1 },
});
