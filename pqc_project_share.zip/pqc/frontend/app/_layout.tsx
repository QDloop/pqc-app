import 'react-native-gesture-handler';
import { Slot, useRouter, useSegments } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { SessionProvider, useSession } from '../context/auth';
import { View, ActivityIndicator, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../constants/Colors';
import { ThemeProvider, useTheme } from '../context/ThemeContext';
import * as LocalAuthentication from 'expo-local-authentication';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { api } from '../services/api';

const GlobalClock = () => {
  const [time, setTime] = useState(new Date());
  const { theme } = useTheme();

  useEffect(() => {
    const int = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(int);
  }, []);

  return (
    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', padding: 8, paddingTop: 40, backgroundColor: theme.background }}>
      <Ionicons name="time-outline" size={16} color={theme.primary} style={{ marginRight: 6 }} />
      <Text style={{ color: theme.text, fontSize: 12, fontWeight: 'bold' }}>{time.toLocaleString()}</Text>
    </View>
  );
};

function InitialLayout() {
  const { session, role, isLoading } = useSession();
  const segments = useSegments();
  const router = useRouter();

  const [bioAuthed, setBioAuthed] = useState(false);
  const [bioChecking, setBioChecking] = useState(true);
  const { theme } = useTheme();

  useEffect(() => {
    if (session) {
      api.ping(session).catch(() => { });
      const int = setInterval(() => api.ping(session).catch(() => { }), 15000);
      return () => clearInterval(int);
    }
  }, [session]);

  useEffect(() => {
    const checkBio = async () => {
      if (!session) {
        setBioAuthed(true);
        setBioChecking(false);
        return;
      }
      const useBio = await AsyncStorage.getItem('use_biometrics');
      if (useBio === 'true' && !bioAuthed) {
        setBioChecking(true);
        const auth = await LocalAuthentication.authenticateAsync({ promptMessage: 'Verify Identity for Quantum Lock' });
        if (auth.success) setBioAuthed(true);
        setBioChecking(false);
      } else {
        setBioAuthed(true);
        setBioChecking(false);
      }
    };
    if (!isLoading) checkBio();
  }, [isLoading, session, bioAuthed]);

  useEffect(() => {
    if (isLoading || bioChecking || (!bioAuthed && session)) return;

    const timer = setTimeout(() => {
      const isAuthGroup = segments[0] === '(admin)' || segments[0] === '(user)' || segments[0] === '(lock)';
      const isLoginPage = segments[0] === 'login';

      if (!session) {
        if (!isLoginPage) {
          router.replace('/login');
        }
      } else if (session) {
        if (isLoginPage || !segments.length) {
          if (role === 'User') router.replace('/(user)');
          else if (role === 'Admin') router.replace('/(admin)');
          else if (role === 'Lock') router.replace('/(lock)');
        }
      }
    }, 1);

    return () => clearTimeout(timer);
  }, [session, role, segments, isLoading, bioChecking, bioAuthed]);

  if (isLoading || bioChecking || (!bioAuthed && session)) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.background }}>
        <Ionicons name="lock-closed" size={48} color={theme.primary} style={{ marginBottom: 20 }} />
        <ActivityIndicator size="large" color={theme.primary} />
        {!bioAuthed && !bioChecking && session && (
          <Text style={{ marginTop: 20, color: theme.danger, fontWeight: 'bold' }}>Biometric Authentication Failed</Text>
        )}
      </View>
    )
  }
  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <GlobalClock />
      <Slot />
    </View>
  );
}

export default function RootLayout() {
  return (
    <SessionProvider>
      <ThemeProvider>
        <InitialLayout />
      </ThemeProvider>
    </SessionProvider>
  );
}
