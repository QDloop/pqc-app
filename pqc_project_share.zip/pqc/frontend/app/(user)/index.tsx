import React, { useEffect, useState, useRef } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Modal, TextInput, Alert, ActivityIndicator, Animated, Image, Platform } from 'react-native';
import { Colors } from '../../constants/Colors';
import { api } from '../../services/api';
import { useSession } from '../../context/auth';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function LocksScreen() {
    const { session } = useSession();
    const [locks, setLocks] = useState<any[]>([]);
    const [stats, setStats] = useState<any>(null);
    const [health, setHealth] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [modalVisible, setModalVisible] = useState(false);
    const [selectedLock, setSelectedLock] = useState<any>(null);
    const [password, setPassword] = useState('');
    const [unlocking, setUnlocking] = useState(false);

    useEffect(() => {
        loadLocks();

        const interval = setInterval(() => {
            loadLocks();
        }, 3000);

        return () => {
            clearInterval(interval);
        };
    }, []);

    const loadLocks = async () => {
        try {
            const [locksData, statsData, healthData] = await Promise.all([
                api.getLocks(session!),
                api.getMyStats(session!),
                api.getSystemHealth(session!)
            ]);

            if (Array.isArray(locksData)) setLocks(locksData);
            if (statsData) setStats(statsData);
            if (healthData) setHealth(healthData);

        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    const handleUnlockRequest = (lock: any) => {
        setSelectedLock(lock);
        setModalVisible(true);
    };

    const confirmUnlock = async () => {
        setUnlocking(true);
        try {
            // Step 4: Send Unlock Command
            const res = await api.unlock(session!, selectedLock.id, password);
            setModalVisible(false);
            setPassword('');
            if (res.error) {
                Alert.alert("Unlock Failed", res.error);
            } else {
                Alert.alert("Success", "Device Unlocked Successfully");
                loadLocks(); // Refresh status
            }
        } catch (e) {
            Alert.alert("Error", "Network request failed");
        } finally {
            setUnlocking(false);
        }
    };

    const handleRelock = async (lockId: string) => {
        try {
            const res = await api.relock(session!, lockId);
            if (res.error) {
                Alert.alert("Relock Failed", res.error);
            } else {
                Alert.alert("Success", "Device Relocked Successfully");
                loadLocks();
            }
        } catch (e) {
            Alert.alert("Error", "Network request failed");
        }
    };

    const renderLock = ({ item }: { item: any }) => {
        const isLocked = item.status === 'Locked';
        return (
            <View style={styles.card}>
                <View style={styles.cardHeader}>
                    <View style={[styles.iconContainer, { backgroundColor: isLocked ? '#FEE2E2' : '#D1FAE5' }]}>
                        <Ionicons
                            name={isLocked ? "lock-closed" : "lock-open"}
                            size={24}
                            color={isLocked ? '#EF4444' : '#10B981'}
                        />
                    </View>
                    <View style={styles.headerText}>
                        <Text style={styles.lockName}>{item.name}</Text>
                        <Text style={styles.lockId}>ID: {item.id}</Text>
                        <Text style={styles.lockType}>{item.type || 'Standard Lock'}</Text>
                    </View>
                </View>

                <View style={styles.statusContainer}>
                    <View style={[styles.statusBadge, { backgroundColor: isLocked ? '#EF4444' : '#10B981' }]}>
                        <Text style={[styles.statusText, { color: '#FFFFFF' }]}>{item.status.toUpperCase()}</Text>
                    </View>
                    <Text style={styles.lastSync}>Updated Just Now</Text>
                </View>

                <TouchableOpacity
                    style={[styles.unlockButton, !isLocked && { backgroundColor: '#EF4444', shadowColor: '#EF4444' }]}
                    onPress={() => isLocked ? handleUnlockRequest(item) : handleRelock(item.id)}
                >
                    <Ionicons name={isLocked ? "key-outline" : "lock-closed-outline"} size={22} color="#FFFFFF" style={{ marginRight: 8 }} />
                    <Text style={styles.unlockButtonText}>{isLocked ? "UNLOCK DEVICE" : "RELOCK DEVICE"}</Text>
                </TouchableOpacity>
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#F8FAFC', '#E2E8F0']} style={styles.background} />

            <View style={styles.header}>
                <Text style={styles.headerTitle}>Quantum Hub</Text>
                <Text style={styles.headerSubtitle}>Post-Quantum Authenticated Network</Text>
            </View>

            {loading ? <ActivityIndicator size="large" color="#2563EB" style={{ marginTop: 50 }} /> : (
                <FlatList
                    data={locks}
                    renderItem={renderLock}
                    keyExtractor={(item) => item.id}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    refreshing={loading}
                    onRefresh={loadLocks}
                    ListHeaderComponent={
                        <View style={styles.dashboardWidgetContainer}>
                            {/* System Health Widget */}
                            {health && (
                                <View style={styles.healthWidget}>
                                    <View style={styles.healthHeader}>
                                        <Ionicons name="shield-checkmark" size={20} color="#10B981" />
                                        <Text style={styles.healthTitle}>System Health Matrix</Text>
                                    </View>
                                    <View style={styles.healthGrid}>
                                        <View style={styles.healthStat}>
                                            <Text style={styles.healthLabel}>Handshake</Text>
                                            <Text style={styles.healthValue}>{health.handshake}</Text>
                                        </View>
                                        <View style={styles.healthStat}>
                                            <Text style={styles.healthLabel}>Roundtrip</Text>
                                            <Text style={styles.healthValue}>{health.latency}</Text>
                                        </View>
                                        <View style={styles.healthStat}>
                                            <Text style={styles.healthLabel}>PQC Tunnel</Text>
                                            <Text style={styles.healthValue}>{health.encryption}</Text>
                                        </View>
                                    </View>
                                </View>
                            )}

                            {/* Personal Stats Widget */}
                            {stats && (
                                <View style={styles.statsWidget}>
                                    <Text style={styles.statsWidgetTitle}>Personal Activity</Text>
                                    <View style={styles.statsRow}>
                                        <View style={styles.statBox}>
                                            <Text style={styles.statBoxVal}>{stats.assigned_locks}</Text>
                                            <Text style={styles.statBoxLabel}>Authorized Locks</Text>
                                        </View>
                                        <View style={styles.divider} />
                                        <View style={styles.statBox}>
                                            <Text style={styles.statBoxVal}>{stats.lifetime_unlocks}</Text>
                                            <Text style={styles.statBoxLabel}>Lifetime Unlocks</Text>
                                        </View>
                                    </View>
                                </View>
                            )}

                            <Text style={styles.sectionTitle}>Authorized Operations</Text>
                        </View>
                    }
                    ListEmptyComponent={<Text style={styles.emptyText}>No authorized locks found. Contact your admin to request access.</Text>}
                />
            )}

            {/* Password Verification Modal */}
            <Modal visible={modalVisible} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Ionicons name="shield-checkmark" size={32} color={Colors.light.primary} />
                            <Text style={styles.modalTitle}>Security Check</Text>
                        </View>
                        <Text style={styles.modalSubtitle}>Device selected. Enter password to authorize unlock.</Text>

                        <Text style={styles.inputLabel}>Password Verification</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Enter your secure password"
                            secureTextEntry
                            value={password}
                            onChangeText={setPassword}
                            autoFocus
                        />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.cancelBtn} onPress={() => { setModalVisible(false); setPassword(''); }}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.confirmBtn} onPress={confirmUnlock} disabled={unlocking}>
                                {unlocking ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.confirmText}>Unlock Device</Text>}
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },
    background: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    header: { padding: 24, paddingBottom: 10, paddingTop: 60 },
    headerTitle: { fontSize: 32, fontWeight: '900', color: '#1E293B', letterSpacing: 0.5 },
    headerSubtitle: { fontSize: 14, color: '#64748B', marginTop: 4 },
    listContent: { padding: 24, paddingBottom: 100 },

    // Dashboard Widget Styles
    dashboardWidgetContainer: {
        marginBottom: 24,
    },
    healthWidget: {
        backgroundColor: '#1E293B',
        borderRadius: 20,
        padding: 20,
        marginBottom: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 6,
    },
    healthHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
    healthTitle: { color: '#F8FAFC', fontSize: 16, fontWeight: 'bold', marginLeft: 8 },
    healthGrid: { flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 },
    healthStat: { flexBasis: '46%' },
    healthLabel: { color: '#94A3B8', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
    healthValue: { color: '#38BDF8', fontSize: 13, fontWeight: '700', fontFamily: 'monospace' },

    statsWidget: {
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        padding: 20,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: '#E2E8F0',
    },
    statsWidgetTitle: { fontSize: 14, fontWeight: 'bold', color: '#64748B', textTransform: 'uppercase', marginBottom: 16 },
    statsRow: { flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center' },
    statBox: { alignItems: 'center' },
    statBoxVal: { fontSize: 24, fontWeight: '900', color: '#1E293B' },
    statBoxLabel: { fontSize: 12, color: '#64748B', marginTop: 4 },
    divider: { width: 1, height: 40, backgroundColor: '#E2E8F0' },

    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1E293B',
        marginBottom: 16,
        paddingLeft: 4,
    },

    card: {
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 24,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: '#F1F5F9',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.05,
        shadowRadius: 20,
        elevation: 5,
    },
    cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
    iconContainer: { width: 56, height: 56, borderRadius: 28, justifyContent: 'center', alignItems: 'center', marginRight: 16, borderWidth: 1, borderColor: '#F1F5F9' },
    headerText: { flex: 1 },
    lockName: { fontSize: 20, fontWeight: 'bold', color: '#1E293B', marginBottom: 4 },
    lockId: { fontSize: 13, color: '#64748B', fontFamily: 'monospace' },
    lockType: { fontSize: 12, color: '#2563EB', marginTop: 4, fontWeight: '700', textTransform: 'uppercase' },
    statusContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, backgroundColor: '#F8FAFC', padding: 12, borderRadius: 12 },
    statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
    statusText: { fontSize: 12, fontWeight: 'bold', letterSpacing: 1 },
    lastSync: { fontSize: 12, color: '#94A3B8', fontStyle: 'italic' },
    unlockButton: {
        backgroundColor: '#2563EB',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 18,
        borderRadius: 16,
        shadowColor: '#2563EB',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.3,
        shadowRadius: 12,
        elevation: 4,
    },
    unlockButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', letterSpacing: 0.5 },
    emptyText: { textAlign: 'center', marginTop: 40, color: '#64748B', fontSize: 16 },

    // Modals
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 24 },
    modalContent: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.1, shadowRadius: 20, elevation: 10 },
    modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
    modalTitle: { fontSize: 22, fontWeight: 'bold', color: '#1E293B', marginLeft: 12 },
    modalSubtitle: { fontSize: 14, color: '#64748B', marginBottom: 24, lineHeight: 22 },
    inputLabel: { fontSize: 12, fontWeight: 'bold', color: '#2563EB', marginBottom: 8, textTransform: 'uppercase' },
    input: {
        borderWidth: 1,
        borderColor: '#E2E8F0',
        borderRadius: 12,
        padding: 18,
        fontSize: 16,
        marginBottom: 24,
        backgroundColor: '#F8FAFC',
        color: '#1E293B'
    },
    modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' },
    cancelBtn: { paddingHorizontal: 20, paddingVertical: 12, marginRight: 8 },
    cancelText: { color: '#64748B', fontWeight: 'bold', fontSize: 16 },
    confirmBtn: { backgroundColor: '#2563EB', paddingHorizontal: 24, paddingVertical: 14, borderRadius: 12, minWidth: 120, alignItems: 'center' },
    confirmText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
});
