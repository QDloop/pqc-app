import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, ActivityIndicator, FlatList, Image } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useSession } from '../../context/auth';
import { api } from '../../services/api';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../../context/ThemeContext';
import * as ImagePicker from 'expo-image-picker';

export default function ProfileScreen() {
    const { session, signOut, user } = useSession();
    const { theme } = useTheme();

    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [myLogs, setMyLogs] = useState<any[]>([]);
    const [profilePic, setProfilePic] = useState<string | null>(user?.profile_pic || null);

    React.useEffect(() => {
        const fetchLogs = async () => {
            try {
                const logsData = await api.getMyActivity(session!);
                if (Array.isArray(logsData)) {
                    setMyLogs(logsData);
                }
            } catch (e) {
                console.error("Failed to load personal logs", e);
            }
        };
        fetchLogs();
    }, []);

    const handleChangePassword = async () => {
        if (!oldPassword || !newPassword || !confirmPassword) {
            Alert.alert("Error", "Please fill in all fields");
            return;
        }
        if (newPassword !== confirmPassword) {
            Alert.alert("Error", "New passwords do not match");
            return;
        }

        setLoading(true);
        try {
            const res = await api.changePassword(session!, oldPassword, newPassword);
            if (res.error) {
                Alert.alert("Failed", res.error);
            } else {
                Alert.alert("Success", "Password updated successfully");
                setOldPassword('');
                setNewPassword('');
                setConfirmPassword('');
            }
        } catch (e) {
            Alert.alert("Error", "Network request failed");
        } finally {
            setLoading(false);
        }
    };

    const pickProfilePic = async () => {
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.5,
            base64: true
        });
        if (!result.canceled && result.assets[0].base64) {
            const b64 = `data:image/jpeg;base64,${result.assets[0].base64}`;
            setProfilePic(b64);
            try {
                await api.updateProfilePic(session!, b64);
                Alert.alert("Success", "Profile picture updated");
            } catch (e) {
                Alert.alert("Error", "Could not save profile picture server-side");
            }
        }
    };

    return (
        <View style={[styles.container, { backgroundColor: theme.background }]}>
            <FlatList
                data={[]} // Used simply for scrolling the entire screen
                keyExtractor={() => "dummy"}
                renderItem={() => null}
                showsVerticalScrollIndicator={false}
                ListHeaderComponent={
                    <View>
                        <View style={[styles.header, { backgroundColor: theme.primary }]}>
                            <TouchableOpacity style={styles.avatar} onPress={pickProfilePic}>
                                {profilePic ? (
                                    <Image source={{ uri: profilePic }} style={{ width: 80, height: 80, borderRadius: 40 }} />
                                ) : (
                                    <Ionicons name="person" size={40} color="#FFF" />
                                )}
                                <View style={[styles.editIcon, { backgroundColor: theme.card }]}>
                                    <Ionicons name="pencil" size={12} color={theme.text} />
                                </View>
                            </TouchableOpacity>
                            <Text style={styles.username}>{user?.name || "User Account"}</Text>
                            <Text style={styles.role}>{user?.role || "Authorized Access Level"}</Text>
                        </View>

                        <View style={[styles.formContainer, { backgroundColor: theme.card }]}>
                            <Text style={[styles.sectionTitle, { color: theme.text }]}>Security Settings</Text>
                            <Text style={[styles.label, { color: theme.secondary }]}>Current Password</Text>
                            <TextInput
                                style={[styles.input, { backgroundColor: theme.background, borderColor: theme.border, color: theme.text }]}
                                secureTextEntry
                                value={oldPassword}
                                onChangeText={setOldPassword}
                                placeholder="Enter current password"
                                placeholderTextColor={theme.inactive}
                            />

                            <Text style={[styles.label, { color: theme.secondary }]}>New Password</Text>
                            <TextInput
                                style={[styles.input, { backgroundColor: theme.background, borderColor: theme.border, color: theme.text }]}
                                secureTextEntry
                                value={newPassword}
                                onChangeText={setNewPassword}
                                placeholder="Enter new password"
                                placeholderTextColor={theme.inactive}
                            />

                            <Text style={[styles.label, { color: theme.secondary }]}>Confirm New Password</Text>
                            <TextInput
                                style={[styles.input, { backgroundColor: theme.background, borderColor: theme.border, color: theme.text }]}
                                secureTextEntry
                                value={confirmPassword}
                                onChangeText={setConfirmPassword}
                                placeholder="Repeat new password"
                                placeholderTextColor={theme.inactive}
                            />

                            <TouchableOpacity style={[styles.updateButton, { backgroundColor: theme.primary }]} onPress={handleChangePassword} disabled={loading}>
                                {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.updateButtonText}>Update Password</Text>}
                            </TouchableOpacity>
                        </View>

                        <View style={[styles.logsContainer, { backgroundColor: theme.card }]}>
                            <View style={styles.logsHeader}>
                                <Ionicons name="time-outline" size={20} color={theme.text} />
                                <Text style={[styles.sectionTitleLogs, { color: theme.text }]}>Recent Security Events</Text>
                            </View>

                            {myLogs.length === 0 ? (
                                <Text style={styles.emptyLogsText}>No recent activity found.</Text>
                            ) : (
                                myLogs.map((log: any, index: number) => (
                                    <View key={`log-${log.id}-${index}`} style={[styles.logItem, { borderBottomColor: theme.border }]}>
                                        <View style={[
                                            styles.logIconBg,
                                            { backgroundColor: log.result === 'Success' ? theme.success + '20' : theme.danger + '20' }
                                        ]}>
                                            <Ionicons
                                                name={log.action === 'Unlock' ? "lock-open" : "alert-circle"}
                                                size={16}
                                                color={log.result === 'Success' ? theme.success : theme.danger}
                                            />
                                        </View>
                                        <View style={styles.logContent}>
                                            <Text style={[styles.logAction, { color: theme.text }]}>{log.action} • {log.lock_name}</Text>
                                            <Text style={[styles.logTime, { color: theme.secondary }]}>{new Date(log.timestamp).toLocaleString()}</Text>
                                        </View>
                                        <View style={[styles.statusBadge, { backgroundColor: log.result === 'Success' ? theme.success + '20' : theme.danger + '20' }]}>
                                            <Text style={[styles.statusText, { color: log.result === 'Success' ? theme.success : theme.danger }]}>
                                                {log.result}
                                            </Text>
                                        </View>
                                    </View>
                                ))
                            )}
                        </View>

                        <TouchableOpacity style={[styles.logoutButton, { borderColor: theme.danger, backgroundColor: theme.danger + '10' }]} onPress={signOut}>
                            <Text style={[styles.logoutText, { color: theme.danger }]}>Sign Out from Secure Network</Text>
                        </TouchableOpacity>
                        <View style={{ height: 100 }} />
                    </View>
                }
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F5F7FA' },
    header: {
        backgroundColor: Colors.light.primary,
        padding: 30,
        alignItems: 'center',
        paddingTop: 60,
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
        marginBottom: 20,
    },
    avatar: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: 'rgba(255,255,255,0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
        position: 'relative'
    },
    editIcon: {
        position: 'absolute',
        bottom: 0,
        right: 0,
        width: 24,
        height: 24,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    username: { fontSize: 24, fontWeight: 'bold', color: '#FFF' },
    role: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 4 },
    formContainer: {
        backgroundColor: '#FFF',
        margin: 20,
        padding: 24,
        borderRadius: 16,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 20 },
    label: { fontSize: 13, fontWeight: '600', color: '#666', marginBottom: 8, marginLeft: 4 },
    input: {
        backgroundColor: '#F9F9F9',
        borderWidth: 1,
        borderColor: '#EEE',
        borderRadius: 10,
        padding: 14,
        marginBottom: 16,
        color: '#333',
    },
    updateButton: {
        backgroundColor: Colors.light.primary,
        padding: 16,
        borderRadius: 10,
        alignItems: 'center',
        marginTop: 10,
    },
    updateButtonText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },

    // Logs Section
    logsContainer: {
        backgroundColor: '#FFF',
        marginHorizontal: 20,
        marginBottom: 20,
        padding: 24,
        borderRadius: 16,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
    },
    logsHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
        gap: 8,
    },
    sectionTitleLogs: { fontSize: 18, fontWeight: 'bold', color: '#1E293B' },
    emptyLogsText: { color: '#64748B', fontStyle: 'italic', textAlign: 'center', marginTop: 10, paddingBottom: 10 },
    logItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#F1F5F9',
    },
    logIconBg: {
        width: 32,
        height: 32,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    logContent: { flex: 1 },
    logAction: { fontSize: 14, fontWeight: 'bold', color: '#1E293B' },
    logTime: { fontSize: 12, color: '#64748B', marginTop: 2 },
    statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
    statusSuccess: { backgroundColor: '#D1FAE5' },
    statusFailed: { backgroundColor: '#FEE2E2' },
    statusText: { fontSize: 10, fontWeight: 'bold' },

    logoutButton: {
        marginHorizontal: 20,
        padding: 16,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: Colors.light.error,
        backgroundColor: '#FEF2F2',
        alignItems: 'center',
    },
    logoutText: { color: Colors.light.error, fontWeight: 'bold', fontSize: 16 },
});
