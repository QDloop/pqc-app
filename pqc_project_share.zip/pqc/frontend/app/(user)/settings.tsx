import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert, Modal, TextInput, ActionSheetIOS, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Toast from 'react-native-toast-message';
import { useSession } from '../../context/auth';
import { useTheme, ThemeType, Themes } from '../../context/ThemeContext';

const ClockHeader = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const int = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(int);
    }, []);
    return (
        <View style={{ flexDirection: 'row', justifyContent: 'center', padding: 10, backgroundColor: '#0F172A' }}>
            <Ionicons name="time-outline" size={16} color="#38BDF8" style={{ marginRight: 6 }} />
            <Text style={{ color: '#F8FAFC', fontSize: 12, fontWeight: 'bold' }}>{time.toLocaleString()}</Text>
        </View>
    );
};

export default function SettingsScreen() {
    const { signOut } = useSession();
    const { theme, themeName, setTheme } = useTheme();
    const [language, setLanguage] = useState('English');
    const [saveLoginInfo, setSaveLoginInfo] = useState(true);
    const [biometricsEnabled, setBiometricsEnabled] = useState(false);

    // UI states
    const [feedbackVisible, setFeedbackVisible] = useState(false);
    const [feedbackText, setFeedbackText] = useState('');
    const [faqVisible, setFaqVisible] = useState(false);

    useEffect(() => {
        (async () => {
            const bio = await AsyncStorage.getItem('use_biometrics');
            if (bio === 'true') setBiometricsEnabled(true);
            const saveLog = await AsyncStorage.getItem('save_login');
            if (saveLog === 'false') setSaveLoginInfo(false);
            const lang = await AsyncStorage.getItem('app_lang');
            if (lang) setLanguage(lang);
        })();
    }, []);

    const toggleBiometric = async (val: boolean) => {
        if (val) {
            const hasHardware = await LocalAuthentication.hasHardwareAsync();
            if (!hasHardware) {
                return Alert.alert("Not Supported", "Biometric hardware is not available on this device.");
            }
            const auth = await LocalAuthentication.authenticateAsync({ promptMessage: 'Verify standard biometric identity' });
            if (auth.success) {
                setBiometricsEnabled(true);
                AsyncStorage.setItem('use_biometrics', 'true');
                Toast.show({ type: 'success', text1: 'Biometrics Enabled' });
            } else {
                setBiometricsEnabled(false);
            }
        } else {
            setBiometricsEnabled(false);
            AsyncStorage.setItem('use_biometrics', 'false');
        }
    };

    const changeTheme = () => {
        if (Platform.OS === 'ios') {
            ActionSheetIOS.showActionSheetWithOptions(
                { options: ['Cancel', 'Light', 'Dark', 'Eye Comfort', 'Cyan'], cancelButtonIndex: 0 },
                (idx) => {
                    const themesMap: ThemeType[] = ['light', 'light', 'dark', 'eye_comfort', 'cyan'];
                    if (idx !== 0) { setTheme(themesMap[idx]); }
                }
            );
        } else {
            Alert.alert("Choose App Theme", "Select your preferred visual mode:", [
                { text: 'Light', onPress: () => setTheme('light') },
                { text: 'Dark', onPress: () => setTheme('dark') },
                { text: 'Eye Comfort', onPress: () => setTheme('eye_comfort') },
                { text: 'Cyan', onPress: () => setTheme('cyan') },
                { text: 'Cancel', style: 'cancel' }
            ]);
        }
    };

    const toggleSaveLogin = (val: boolean) => {
        setSaveLoginInfo(val);
        AsyncStorage.setItem('save_login', String(val));
        if (!val) SecureStore.deleteItemAsync('saved_email');
    };

    const handleLanguage = () => {
        if (Platform.OS === 'ios') {
            ActionSheetIOS.showActionSheetWithOptions(
                { options: ['Cancel', 'English', 'Spanish', 'French', 'German'], cancelButtonIndex: 0 },
                (idx) => {
                    const langs = ['Cancel', 'English', 'Spanish', 'French', 'German'];
                    if (idx !== 0) { setLanguage(langs[idx]); AsyncStorage.setItem('app_lang', langs[idx]); }
                }
            );
        } else {
            Alert.alert("Select Language", "Choose your language prefix:", [
                { text: 'English', onPress: () => { setLanguage('English'); AsyncStorage.setItem('app_lang', 'English'); } },
                { text: 'Spanish', onPress: () => { setLanguage('Spanish'); AsyncStorage.setItem('app_lang', 'Spanish'); } },
                { text: 'German', onPress: () => { setLanguage('German'); AsyncStorage.setItem('app_lang', 'German'); } },
                { text: 'Cancel', style: 'cancel' }
            ]);
        }
    };

    const submitFeedback = () => {
        if (!feedbackText.trim()) return;
        setFeedbackVisible(false);
        setFeedbackText('');
        Toast.show({ type: 'success', text1: 'Feedback Received', text2: 'Your logs have been routed to the development team.' });
    };

    const SettingsGroup = ({ title, children }: any) => (
        <View style={styles.group}>
            <Text style={[styles.groupTitle, { color: theme.secondary }]}>{title}</Text>
            <View style={[styles.groupContent, { backgroundColor: theme.card, borderColor: theme.border }]}>
                {children}
            </View>
        </View>
    );

    const SettingsRow = ({ icon, label, rightElement, onPress, destructive }: any) => (
        <TouchableOpacity style={[styles.row, { borderBottomColor: theme.background }]} onPress={onPress} disabled={!onPress}>
            <View style={styles.rowLeft}>
                <View style={[styles.iconBg, { backgroundColor: theme.background }, destructive && { backgroundColor: theme.danger + '20' }]}>
                    <Ionicons name={icon} size={20} color={destructive ? theme.danger : theme.secondary} />
                </View>
                <Text style={[styles.rowLabel, { color: theme.text }, destructive && { color: theme.danger }]}>{label}</Text>
            </View>
            <View style={styles.rowRight}>
                {rightElement ? rightElement : (onPress ? <Ionicons name="chevron-forward" size={20} color={theme.inactive} /> : null)}
            </View>
        </TouchableOpacity>
    );

    return (
        <View style={{ flex: 1, backgroundColor: theme.background }}>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.content}>

                <SettingsGroup title="Display Settings">
                    <SettingsRow
                        icon="color-palette-outline"
                        label={`App Theme (${themeName})`}
                        onPress={changeTheme}
                    />
                    <SettingsRow
                        icon="language-outline"
                        label={`Language (${language})`}
                        onPress={handleLanguage}
                    />
                </SettingsGroup>

                <SettingsGroup title="Privacy & Security">
                    <SettingsRow
                        icon="lock-closed-outline"
                        label="Save Login Info"
                        rightElement={<Switch value={saveLoginInfo} onValueChange={toggleSaveLogin} />}
                    />
                    <SettingsRow
                        icon="finger-print-outline"
                        label="Require Biometrics"
                        rightElement={<Switch value={biometricsEnabled} onValueChange={toggleBiometric} />}
                    />
                </SettingsGroup>

                <SettingsGroup title="Support & Feedback">
                    <SettingsRow
                        icon="help-circle-outline"
                        label="PQC Security FAQs"
                        onPress={() => setFaqVisible(true)}
                    />
                    <SettingsRow
                        icon="chatbox-ellipses-outline"
                        label="File Bug / Send Feedback"
                        onPress={() => setFeedbackVisible(true)}
                    />
                </SettingsGroup>

                <SettingsGroup title="Account">
                    <SettingsRow icon="log-out-outline" label="Sign Out & Shred Token" destructive onPress={signOut} />
                </SettingsGroup>
            </ScrollView>

            <Toast />

            {/* Feedback Modal */}
            <Modal visible={feedbackVisible} animationType="slide" transparent>
                <View style={styles.modalOverlay}>
                    <View style={[styles.modalBox, { backgroundColor: theme.card }]}>
                        <Text style={[styles.modalTitle, { color: theme.text }]}>Submit Secure Feedback</Text>
                        <TextInput
                            style={[styles.modalInput, { color: theme.text, backgroundColor: theme.background, borderColor: theme.border }]}
                            placeholder="Describe your issue or feature request..."
                            placeholderTextColor={theme.secondary}
                            multiline
                            numberOfLines={4}
                            value={feedbackText}
                            onChangeText={setFeedbackText}
                        />
                        <View style={styles.modalActions}>
                            <TouchableOpacity onPress={() => setFeedbackVisible(false)} style={{ padding: 12 }}><Text style={{ color: theme.secondary, fontWeight: 'bold' }}>Cancel</Text></TouchableOpacity>
                            <TouchableOpacity onPress={submitFeedback} style={[styles.modalSubmitBtn, { backgroundColor: theme.primary }]}><Text style={{ color: '#FFF', fontWeight: 'bold' }}>Submit</Text></TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* FAQ Modal */}
            <Modal visible={faqVisible} animationType="slide" presentationStyle="pageSheet">
                <View style={[styles.faqContainer, { backgroundColor: theme.background }]}>
                    <View style={[styles.faqHeader, { borderBottomColor: theme.border }]}>
                        <Text style={[styles.faqTitle, { color: theme.text }]}>Security FAQs</Text>
                        <TouchableOpacity onPress={() => setFaqVisible(false)}><Ionicons name="close-circle" size={28} color={theme.secondary} /></TouchableOpacity>
                    </View>
                    <ScrollView style={{ padding: 24 }}>
                        <Text style={[styles.faqQ, { color: theme.text }]}>1. What is Post-Quantum Cryptography (PQC)?</Text>
                        <Text style={[styles.faqA, { color: theme.secondary, borderBottomColor: theme.border }]}>PQC refers to cryptographic algorithms (like ML-KEM-512) that are thought to be secure against a cryptanalytic attack by a quantum computer.</Text>

                        <Text style={[styles.faqQ, { color: theme.text }]}>2. Are my chats fully secure?</Text>
                        <Text style={[styles.faqA, { color: theme.secondary, borderBottomColor: theme.border }]}>Yes, chat messages are wrapped tightly within AES-GCM payloads locally before tunneled out via secure web transports.</Text>

                        <Text style={[styles.faqQ, { color: theme.text }]}>3. Why can't I send media in Global HQ?</Text>
                        <Text style={[styles.faqA, { color: theme.secondary, borderBottomColor: theme.border }]}>For performance and security monitoring, large files passing through the general broadcast channels are blocked by enterprise Admin policy. It requires higher permission clearance.</Text>

                        <Text style={[styles.faqQ, { color: theme.text }]}>4. Who can see my audit logs?</Text>
                        <Text style={[styles.faqA, { color: theme.secondary, borderBottomColor: theme.border }]}>Your audit logs are mapped securely to your unique ID. Only you and network Administrators with explicit clearance can view unlock history.</Text>

                        <Text style={{ paddingBottom: 60 }} />
                    </ScrollView>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    content: { padding: 24, paddingBottom: 60 },
    group: { marginBottom: 32 },
    groupTitle: { fontSize: 13, fontWeight: '700', color: '#64748B', textTransform: 'uppercase', marginBottom: 12, marginLeft: 8 },
    groupContent: { borderRadius: 16, borderWidth: 1, borderColor: '#F1F5F9', overflow: 'hidden' },
    row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 14, paddingHorizontal: 16, borderBottomWidth: 1 },
    rowLeft: { flexDirection: 'row', alignItems: 'center' },
    iconBg: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
    rowLabel: { fontSize: 16, fontWeight: '500' },
    rowRight: { flexDirection: 'row', alignItems: 'center' },

    // Modals
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 20 },
    modalBox: { width: '100%', borderRadius: 20, padding: 24, elevation: 10 },
    modalTitle: { fontSize: 18, fontWeight: '900', marginBottom: 16 },
    modalInput: { height: 100, borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#334155', textAlignVertical: 'top' },
    modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 16, alignItems: 'center' },
    modalSubmitBtn: { backgroundColor: '#2563EB', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8, marginLeft: 12 },

    faqContainer: { flex: 1 },
    faqHeader: { flexDirection: 'row', justifyContent: 'space-between', padding: 24, paddingTop: 60, borderBottomWidth: 1, borderBottomColor: '#334155' },
    faqTitle: { fontSize: 24, fontWeight: 'bold' },
    faqQ: { fontSize: 16, fontWeight: 'bold', marginBottom: 8, marginTop: 16 },
    faqA: { fontSize: 14, color: '#64748B', lineHeight: 22, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: '#334155' },
});
