import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { Colors } from '../constants/Colors';
import { useSession } from '../context/auth';
import { api } from '../services/api';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export default function LoginScreen() {
    const { signIn } = useSession();
    const [role, setRole] = useState<'User' | 'Admin' | 'Lock'>('User');

    // Auth States
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [deviceId, setDeviceId] = useState('');
    const [deviceToken, setDeviceToken] = useState('');

    // UI Flow States
    const [loading, setLoading] = useState(false);
    const [isSignup, setIsSignup] = useState(false);
    const [isVerifying, setIsVerifying] = useState(false);
    const [otp, setOtp] = useState('');

    // Secret Tap States
    const [tapCount, setTapCount] = useState(0);
    const [lastTapTime, setLastTapTime] = useState(0);

    const handleSecretTap = (targetRole: 'Admin' | 'Lock', requiredTaps: number) => {
        const now = Date.now();
        // Reset if more than 1 second between taps
        if (now - lastTapTime > 1000) {
            setTapCount(1);
        } else {
            const newCount = tapCount + 1;
            setTapCount(newCount);
            if (newCount === requiredTaps) {
                setRole(targetRole);
                setTapCount(0); // reset
                setIsSignup(false);
                setIsVerifying(false);
                Alert.alert('Secret Mode Unlocked', `You are now logging in as ${targetRole}`);
            }
        }
        setLastTapTime(now);
    };

    const handleLogin = async () => {
        setLoading(true);
        try {
            let response;
            if (role === 'Lock') {
                response = await api.login({ device_id: deviceId, password: deviceToken });
            } else {
                response = await api.login({ email, password });
            }

            if (response.error) {
                Alert.alert('Login Failed', response.error);
            } else {
                signIn(response.token, response.role, response);
            }
        } catch (e) {
            Alert.alert('Error', 'Failed to connect to backend');
        } finally {
            setLoading(false);
        }
    };

    const handleSignupRequest = async () => {
        if (!email || !password || !name) {
            Alert.alert('Missing Info', 'Please fill all fields to request access.');
            return;
        }
        setLoading(true);
        try {
            const response = await api.requestSignup(email);
            if (response.error) {
                Alert.alert('Error', response.error);
            } else {
                setIsVerifying(true);
                Alert.alert('Verification Required', response.message);
            }
        } catch (e) {
            Alert.alert('Error', 'Failed to connect to backend');
        } finally {
            setLoading(false);
        }
    };

    const handleSignupVerify = async () => {
        if (!otp) {
            Alert.alert('Missing OTP', 'Please enter the verification code.');
            return;
        }
        setLoading(true);
        try {
            const response = await api.verifySignup({ email, otp, password, name });
            if (response.error) {
                Alert.alert('Verification Failed', response.error);
            } else {
                Alert.alert('Success', 'Account verified! You can now log in.');
                setIsVerifying(false);
                setIsSignup(false);
                setOtp('');
                setPassword(''); // Forcing re-entry for security
            }
        } catch (e) {
            Alert.alert('Error', 'Failed to connect to backend');
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.container}>
            <LinearGradient colors={['#F8FAFC', '#E2E8F0']} style={styles.background} />

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                <View style={styles.header}>
                    <TouchableOpacity
                        activeOpacity={1}
                        onPress={() => handleSecretTap('Lock', 7)}
                    >
                        <View style={styles.logoContainer}>
                            <Ionicons name="shield-checkmark" size={48} color="#2563EB" />
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        activeOpacity={1}
                        onPress={() => handleSecretTap('Admin', 5)}
                    >
                        <Text style={styles.title}>QuantumLock</Text>
                    </TouchableOpacity>
                    <Text style={styles.subtitle}>Post-Quantum Secure Access Level</Text>
                </View>

                <View style={styles.card}>
                    {/* Role tabs hidden. To manually return to User, show a button only if not User */}
                    {role !== 'User' && (
                        <TouchableOpacity
                            style={styles.cancelSecretBtn}
                            onPress={() => {
                                setRole('User');
                                setIsSignup(false);
                                setIsVerifying(false);
                            }}
                        >
                            <Ionicons name="close-circle" size={16} color="#64748B" style={{ marginRight: 4 }} />
                            <Text style={styles.cancelSecretText}>Return to User Login</Text>
                        </TouchableOpacity>
                    )}

                    {role === 'Lock' ? (
                        <>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="hardware-chip-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Enter Device ID"
                                    placeholderTextColor="#94A3B8"
                                    value={deviceId}
                                    onChangeText={setDeviceId}
                                    autoCapitalize="none"
                                />
                            </View>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="key-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Enter Device Token"
                                    placeholderTextColor="#94A3B8"
                                    value={deviceToken}
                                    onChangeText={setDeviceToken}
                                    secureTextEntry
                                />
                            </View>
                            <TouchableOpacity style={styles.loginButton} onPress={handleLogin} disabled={loading}>
                                {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.loginButtonText}>Authenticate</Text>}
                            </TouchableOpacity>
                        </>
                    ) : isVerifying ? (
                        <>
                            <Text style={styles.verificationText}>Please enter the 6-digit verification code sent to {email}</Text>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="chatbubble-ellipses-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Enter 6-Digit OTP"
                                    placeholderTextColor="#94A3B8"
                                    value={otp}
                                    onChangeText={setOtp}
                                    keyboardType="number-pad"
                                    maxLength={6}
                                />
                            </View>
                            <TouchableOpacity style={styles.loginButton} onPress={handleSignupVerify} disabled={loading}>
                                {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.loginButtonText}>Verify & Create Account</Text>}
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.forgotPassword} onPress={() => setIsVerifying(false)}>
                                <Text style={styles.forgotPasswordText}>Cancel</Text>
                            </TouchableOpacity>
                        </>
                    ) : isSignup ? (
                        <>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="person-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Full Name"
                                    placeholderTextColor="#94A3B8"
                                    value={name}
                                    onChangeText={setName}
                                />
                            </View>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="mail-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Official Email"
                                    placeholderTextColor="#94A3B8"
                                    value={email}
                                    onChangeText={setEmail}
                                    autoCapitalize="none"
                                    keyboardType="email-address"
                                />
                            </View>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="lock-closed-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Password"
                                    placeholderTextColor="#94A3B8"
                                    value={password}
                                    onChangeText={setPassword}
                                    secureTextEntry
                                />
                            </View>

                            <TouchableOpacity style={styles.loginButton} onPress={handleSignupRequest} disabled={loading}>
                                {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.loginButtonText}>Request Access</Text>}
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.forgotPassword} onPress={() => setIsSignup(false)}>
                                <Text style={styles.forgotPasswordText}>Already have access? Log in here</Text>
                            </TouchableOpacity>
                        </>
                    ) : (
                        <>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="person-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder={role === 'Admin' ? "Admin Email" : "User Email"}
                                    placeholderTextColor="#94A3B8"
                                    value={email}
                                    onChangeText={setEmail}
                                    autoCapitalize="none"
                                    keyboardType="email-address"
                                />
                            </View>
                            <View style={styles.inputWrapper}>
                                <Ionicons name="lock-closed-outline" size={20} color="#64748B" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Password"
                                    placeholderTextColor="#94A3B8"
                                    value={password}
                                    onChangeText={setPassword}
                                    secureTextEntry
                                />
                            </View>

                            <TouchableOpacity style={styles.loginButton} onPress={handleLogin} disabled={loading}>
                                {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.loginButtonText}>Authenticate</Text>}
                            </TouchableOpacity>

                            {role === 'User' ? (
                                <TouchableOpacity style={styles.forgotPassword} onPress={() => setIsSignup(true)}>
                                    <Text style={styles.forgotPasswordText}>New User? Request Access</Text>
                                </TouchableOpacity>
                            ) : null}
                        </>
                    )}
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },
    background: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
    scrollContent: { flexGrow: 1, justifyContent: 'center', padding: 24 },
    header: { alignItems: 'center', marginBottom: 48 },
    logoContainer: {
        width: 80, height: 80, borderRadius: 40, backgroundColor: '#EFF6FF',
        justifyContent: 'center', alignItems: 'center', marginBottom: 20,
        borderWidth: 1, borderColor: '#DBEAFE', shadowColor: '#2563EB',
        shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 5,
    },
    title: { fontSize: 34, fontWeight: 'bold', color: '#1E293B', letterSpacing: 0.5, marginBottom: 8 },
    subtitle: { fontSize: 14, color: '#64748B', textTransform: 'uppercase', letterSpacing: 1 },
    card: {
        backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, borderWidth: 1,
        borderColor: '#F1F5F9', overflow: 'hidden', shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.05, shadowRadius: 20, elevation: 4,
    },
    roleContainer: { flexDirection: 'row', marginBottom: 32, backgroundColor: '#F1F5F9', borderRadius: 16, padding: 6 },
    roleButton: { flex: 1, paddingVertical: 12, alignItems: 'center', borderRadius: 12 },
    roleButtonActive: { backgroundColor: '#FFFFFF', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
    roleText: { color: '#64748B', fontWeight: '600', fontSize: 14 },
    roleTextActive: { color: '#2563EB', fontWeight: 'bold' },
    cancelSecretBtn: { flexDirection: 'row', alignItems: 'center', alignSelf: 'center', marginBottom: 20, padding: 8, backgroundColor: '#F1F5F9', borderRadius: 8 },
    cancelSecretText: { color: '#64748B', fontSize: 12, fontWeight: '600' },
    verificationText: { fontSize: 14, color: '#64748B', textAlign: 'center', marginBottom: 20, paddingHorizontal: 10, lineHeight: 20 },
    inputWrapper: {
        flexDirection: 'row', alignItems: 'center', backgroundColor: '#F8FAFC',
        borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, marginBottom: 16, paddingHorizontal: 16,
    },
    inputIcon: { marginRight: 12 },
    input: { flex: 1, paddingVertical: 18, fontSize: 16, color: '#1E293B' },
    loginButton: {
        backgroundColor: '#2563EB', borderRadius: 16, padding: 18, alignItems: 'center',
        marginTop: 24, shadowColor: '#2563EB', shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.3, shadowRadius: 12, elevation: 8,
    },
    loginButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },
    forgotPassword: { alignSelf: 'center', marginTop: 24 },
    forgotPasswordText: { color: '#64748B', fontSize: 14, fontWeight: '600' },
});
