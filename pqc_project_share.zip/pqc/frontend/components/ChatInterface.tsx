import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, FlatList, TextInput, TouchableOpacity, ActivityIndicator, KeyboardAvoidingView, Platform, Modal, Image, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import Toast from 'react-native-toast-message';
import * as ImagePicker from 'expo-image-picker';
import { useSession } from '../context/auth';
import { api } from '../services/api';

export default function ChatInterface() {
    const { session, role, user } = useSession();
    const [index, setIndex] = useState(0);
    const [routes] = useState([
        { key: 'global', title: 'Global HQ' },
        { key: 'direct', title: 'Direct Messages' }
    ]);

    const [globalMsgs, setGlobalMsgs] = useState<any[]>([]);
    const [users, setUsers] = useState<any[]>([]);
    const [content, setContent] = useState('');
    const [sending, setSending] = useState(false);
    const [loading, setLoading] = useState(true);

    const [activeChat, setActiveChat] = useState<any>(null);
    const [chatMsgs, setChatMsgs] = useState<any[]>([]);

    const flatListRef = useRef<FlatList>(null);
    const activeMsgCount = useRef(0);

    // New feature states
    const [selectedMsg, setSelectedMsg] = useState<any>(null);
    const [editingMsg, setEditingMsg] = useState<any>(null);
    const [mediaViewerUri, setMediaViewerUri] = useState<string | null>(null);

    const loadData = async () => {
        try {
            const currentRoomId = activeChat ? activeChat.id : 'group';
            // Background read receipt marking
            if (session) {
                api.markRead(session, currentRoomId).catch(() => { });
            }

            if (activeChat) {
                const directMsgs = await api.getMessages(session!, activeChat.id);
                if (Array.isArray(directMsgs)) {
                    if (directMsgs.length > activeMsgCount.current && activeMsgCount.current !== 0) {
                        Toast.show({ type: 'info', text1: 'New Message', text2: `From ${activeChat.name}` });
                    }
                    activeMsgCount.current = directMsgs.length;
                    setChatMsgs(directMsgs);
                }
            } else {
                const [msgs, activeUsers] = await Promise.all([
                    api.getMessages(session!, 'group'),
                    api.getChatUsers(session!)
                ]);
                if (Array.isArray(msgs)) {
                    if (msgs.length > activeMsgCount.current && activeMsgCount.current !== 0) {
                        Toast.show({ type: 'info', text1: 'New Secure Message', text2: 'A new message was broadcasted.' });
                    }
                    activeMsgCount.current = msgs.length;
                    setGlobalMsgs(msgs);
                }
                if (Array.isArray(activeUsers)) setUsers(activeUsers);
            }
        } catch (e) {
            console.error("Failed to load chat data", e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
        const int = setInterval(loadData, 3000);
        return () => clearInterval(int);
    }, [activeChat]);

    const handleSend = async (type: string = 'text', payload: string = content) => {
        if (!payload.trim()) return;
        setSending(true);
        const receiver = activeChat ? activeChat.id : 'group';
        try {
            if (editingMsg) {
                await api.editMessage(session!, editingMsg.id, payload);
                setEditingMsg(null);
            } else {
                await api.sendMessage(session!, receiver, payload, type);
            }
            if (type === 'text') setContent('');
            loadData();
            setTimeout(() => flatListRef.current?.scrollToEnd(), 500);
        } catch (e) {
            Toast.show({ type: 'error', text1: 'Transmission Failed', text2: 'Could not secure connection.' });
        } finally {
            setSending(false);
        }
    };

    const handleDelete = async (msgId: string) => {
        try {
            await api.deleteMessage(session!, msgId);
            setSelectedMsg(null);
            loadData();
        } catch (e) {
            Alert.alert("Error", "Could not delete");
        }
    };

    const handleRecover = async (msgId: string) => {
        try {
            await api.recoverMessage(session!, msgId);
            setSelectedMsg(null);
            loadData();
        } catch (e) {
            Alert.alert("Error", "Could not recover");
        }
    };

    const attachMedia = async () => {
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            base64: true,
            quality: 0.5,
        });
        if (!result.canceled && result.assets[0].base64) {
            const b64 = `data:image/jpeg;base64,${result.assets[0].base64}`;
            handleSend('media', b64);
        }
    };

    const renderTicks = (item: any, isMe: boolean) => {
        if (!isMe || item.type === 'deleted') return null;
        let seenCount = Array.isArray(item.seen_by) ? item.seen_by.length : 0;

        if (seenCount === 0) {
            return <Ionicons name="checkmark" size={14} color="#94A3B8" style={{ marginLeft: 4, marginTop: 2 }} />;
        }

        const isGroupMsg = item.receiver_id === 'group';
        // group expected viewers vs DM
        const expected = isGroupMsg ? (item.total_group_users || 1) : 1;

        if (seenCount >= expected) { // Double blue
            return <Ionicons name="checkmark-done" size={14} color="#38BDF8" style={{ marginLeft: 4, marginTop: 2 }} />;
        }
        // Double gray
        return <Ionicons name="checkmark-done" size={14} color="#94A3B8" style={{ marginLeft: 4, marginTop: 2 }} />;
    };

    const renderMessage = ({ item }: any) => {
        const isMe = user?.id ? (item.sender_id === user.id) : item.sender_id.includes('u_');
        const isSelected = selectedMsg?.id === item.id;

        return (
            <TouchableOpacity
                activeOpacity={0.8}
                onLongPress={() => setSelectedMsg(item)}
                onPress={() => {
                    if (selectedMsg) {
                        setSelectedMsg(isSelected ? null : item);
                    } else if (item.type === 'media') {
                        setMediaViewerUri(item.content);
                    }
                }}
                style={[
                    styles.msgWrapper,
                    isSelected && styles.msgWrapperSelected,
                    isMe ? { alignItems: 'flex-end' } : { alignItems: 'flex-start' }
                ]}
            >
                <View style={[styles.msgContainer, isMe ? styles.myMsg : styles.otherMsg]}>
                    {!isMe && <Text style={styles.senderName}>{item.sender_name}</Text>}
                    <View style={[styles.bubble, isMe ? styles.myBubble : styles.otherBubble, item.type === 'deleted' && styles.deletedBubble]}>
                        {item.type === 'media' ? (
                            <Image source={{ uri: item.content }} style={styles.mediaImage} />
                        ) : (
                            <Text style={[styles.msgText, isMe ? styles.myMsgText : styles.otherMsgText, item.type === 'deleted' && { fontStyle: 'italic', color: '#94A3B8' }]}>
                                {item.content}
                            </Text>
                        )}
                        {item.is_edited && item.type !== 'deleted' && <Text style={[styles.editedText, isMe ? { color: '#E0F2FE' } : { color: '#94A3B8' }]}>(edited)</Text>}
                    </View>
                    <View style={styles.msgFooter}>
                        <Text style={styles.timeText}>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
                        {renderTicks(item, isMe)}
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    const renderRoomUI = (data: any[]) => (
        <View style={styles.tabContainer}>
            <View style={styles.snackbar}>
                <Ionicons name="shield-checkmark" size={16} color="#065F46" />
                <Text style={styles.snackbarText}>End-to-End PQC Encrypted Channel</Text>
            </View>

            {loading ? (
                <View style={styles.progressContainer}>
                    <Text style={styles.progressText}>Establishing Tunnel...</Text>
                    <ActivityIndicator size="large" color="#2563EB" />
                </View>
            ) : (
                <FlatList
                    ref={flatListRef}
                    data={data}
                    keyExtractor={i => i.id}
                    renderItem={renderMessage}
                    contentContainerStyle={styles.listContent}
                    onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
                    onLayout={() => flatListRef.current?.scrollToEnd({ animated: true })}
                />
            )}
        </View>
    );

    const checkEditEligibility = (msg: any) => {
        if (!msg || msg.type === 'deleted') return false;
        const isMe = user?.id ? (msg.sender_id === user.id) : false;
        if (!isMe) return false;
        const timeDiff = (new Date().getTime() - new Date(msg.timestamp).getTime()) / 1000;
        return timeDiff <= 600; // 10 mins
    };

    const renderInputBar = () => {
        if (selectedMsg) {
            // Action Bar for selected message
            return (
                <View style={styles.actionBar}>
                    <TouchableOpacity onPress={() => setSelectedMsg(null)} style={styles.actionBtn}>
                        <Ionicons name="close" size={24} color="#1E293B" />
                    </TouchableOpacity>
                    <View style={{ flex: 1 }} />

                    {role === 'Admin' && selectedMsg.type === 'deleted' && (
                        <TouchableOpacity onPress={() => handleRecover(selectedMsg.id)} style={styles.actionBtn}>
                            <Ionicons name="arrow-undo" size={24} color="#1E293B" />
                        </TouchableOpacity>
                    )}

                    {checkEditEligibility(selectedMsg) && (
                        <TouchableOpacity onPress={() => { setEditingMsg(selectedMsg); setContent(selectedMsg.content); setSelectedMsg(null); }} style={styles.actionBtn}>
                            <Ionicons name="pencil" size={22} color="#1E293B" />
                        </TouchableOpacity>
                    )}

                    <TouchableOpacity onPress={() => {
                        Alert.alert("Message Info", `Seen by ${Array.isArray(selectedMsg.seen_by) ? selectedMsg.seen_by.length : 0} device(s).\nSent at: ${new Date(selectedMsg.timestamp).toLocaleString()}`);
                    }} style={styles.actionBtn}>
                        <Ionicons name="information-circle-outline" size={24} color="#1E293B" />
                    </TouchableOpacity>

                    {(user?.id === selectedMsg.sender_id || role === 'Admin') && selectedMsg.type !== 'deleted' && (
                        <TouchableOpacity onPress={() => handleDelete(selectedMsg.id)} style={styles.actionBtn}>
                            <Ionicons name="trash" size={22} color="#EF4444" />
                        </TouchableOpacity>
                    )}
                </View>
            );
        }

        return (
            <View style={styles.inputContainer}>
                {editingMsg && (
                    <TouchableOpacity style={styles.cancelEditBtn} onPress={() => { setEditingMsg(null); setContent(''); }}>
                        <Ionicons name="close-circle" size={20} color="#EF4444" />
                    </TouchableOpacity>
                )}
                {!editingMsg && (
                    <TouchableOpacity style={styles.attachBtn} onPress={attachMedia}>
                        <Ionicons name="image" size={24} color="#64748B" />
                    </TouchableOpacity>
                )}
                <TextInput
                    style={styles.input}
                    placeholder={editingMsg ? "Edit message..." : "Type a secure message..."}
                    value={content}
                    onChangeText={setContent}
                    multiline
                />
                <TouchableOpacity style={styles.sendBtn} onPress={() => handleSend('text')} disabled={sending || !content.trim()}>
                    {sending ? <ActivityIndicator color="#FFF" size="small" /> : <Ionicons name={editingMsg ? "checkmark" : "send"} size={18} color="#FFF" style={{ marginLeft: editingMsg ? 0 : 3 }} />}
                </TouchableOpacity>
            </View>
        );
    };

    const renderDirectTab = () => (
        <View style={styles.tabContainer}>
            <FlatList
                data={users}
                keyExtractor={i => i.id}
                renderItem={({ item }) => (
                    <TouchableOpacity style={[styles.userCard, item.has_conversed ? styles.conversedCard : styles.unconversedCard]} onPress={() => {
                        activeMsgCount.current = 0;
                        setLoading(true);
                        setActiveChat(item);
                    }}>
                        <View style={[styles.avatar, item.has_conversed ? { backgroundColor: '#2563EB' } : {}]}>
                            <Ionicons name="person" size={20} color="#FFF" />
                        </View>
                        <View style={styles.userInfo}>
                            <Text style={styles.userName}>{item.name}</Text>
                            <Text style={styles.userRole}>{item.role}</Text>
                        </View>
                        {item.has_conversed && <View style={styles.activeDot} />}
                    </TouchableOpacity>
                )}
                contentContainerStyle={{ padding: 16 }}
                ListEmptyComponent={<Text style={styles.emptyText}>No contacts found.</Text>}
            />
        </View>
    );

    const renderScene = React.useCallback(({ route }: any) => {
        switch (route.key) {
            case 'global': return renderRoomUI(globalMsgs);
            case 'direct': return renderDirectTab();
            default: return null;
        }
    }, [globalMsgs, users, loading, selectedMsg]);

    const MediaViewer = () => (
        <Modal visible={!!mediaViewerUri} transparent={true} onRequestClose={() => setMediaViewerUri(null)}>
            <View style={styles.modalBg}>
                <TouchableOpacity style={styles.closeModal} onPress={() => setMediaViewerUri(null)}>
                    <Ionicons name="close" size={32} color="#FFF" />
                </TouchableOpacity>
                {mediaViewerUri && <Image source={{ uri: mediaViewerUri }} style={styles.fullImage} resizeMode="contain" />}
            </View>
        </Modal>
    );

    const MainLayout = () => {
        if (activeChat) {
            return (
                <View style={styles.tabContainer}>
                    <View style={styles.dmHeader}>
                        <TouchableOpacity onPress={() => { setActiveChat(null); activeMsgCount.current = 0; setLoading(true); setSelectedMsg(null); }} style={styles.backBtn}>
                            <Ionicons name="arrow-back" size={24} color="#1E293B" />
                        </TouchableOpacity>
                        <View style={styles.dmHeaderInfo}>
                            <Text style={styles.dmHeaderTitle}>{activeChat.name}</Text>
                            <Text style={styles.dmHeaderStatus}>PQC Encrypted Session Active</Text>
                        </View>
                    </View>
                    {renderRoomUI(chatMsgs)}
                    {renderInputBar()}
                </View>
            );
        }

        return (
            <View style={styles.tabContainer}>
                <TabView
                    navigationState={{ index, routes }}
                    renderScene={renderScene}
                    onIndexChange={setIndex}
                    initialLayout={{ width: 400 }}
                    renderTabBar={props => (
                        <TabBar
                            {...props}
                            indicatorStyle={{ backgroundColor: '#2563EB', height: 3, borderRadius: 3 }}
                            style={{ backgroundColor: '#1E293B' }}
                            activeColor="#FFFFFF"
                            inactiveColor="#94A3B8"
                        />
                    )}
                />
                {index === 0 && renderInputBar()}
            </View>
        );
    }

    return (
        <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <MainLayout />
            <MediaViewer />
            <Toast />
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F8FAFC' },
    tabContainer: { flex: 1, backgroundColor: '#F8FAFC' },
    snackbar: { backgroundColor: '#D1FAE5', padding: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
    snackbarText: { color: '#065F46', fontSize: 12, marginLeft: 6, fontWeight: '600' },
    progressContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    progressText: { color: '#64748B', marginBottom: 16, fontWeight: '500' },

    dmHeader: { flexDirection: 'row', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#E2E8F0', backgroundColor: '#FFF' },
    backBtn: { padding: 8, marginRight: 8 },
    dmHeaderInfo: { flex: 1 },
    dmHeaderTitle: { fontSize: 18, fontWeight: 'bold', color: '#1E293B' },
    dmHeaderStatus: { fontSize: 11, color: '#10B981', fontWeight: '600' },

    listContent: { padding: 16, paddingBottom: 20 },
    msgWrapper: { width: '100%', paddingVertical: 2 },
    msgWrapperSelected: { backgroundColor: '#DBEAFE' },
    msgContainer: { marginBottom: 10, maxWidth: '82%', paddingHorizontal: 4 },
    myMsg: { alignSelf: 'flex-end', alignItems: 'flex-end' },
    otherMsg: { alignSelf: 'flex-start', alignItems: 'flex-start' },
    senderName: { fontSize: 11, color: '#64748B', marginBottom: 2, marginLeft: 4, fontWeight: '700' },
    bubble: { padding: 10, borderRadius: 16, elevation: 1, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05 },
    myBubble: { backgroundColor: '#2563EB', borderBottomRightRadius: 4 },
    otherBubble: { backgroundColor: '#FFFFFF', borderBottomLeftRadius: 4, borderWidth: 1, borderColor: '#E2E8F0' },
    deletedBubble: { backgroundColor: '#F1F5F9', borderColor: '#E2E8F0', borderWidth: 1 },
    msgText: { fontSize: 15, lineHeight: 22 },
    myMsgText: { color: '#FFFFFF' },
    otherMsgText: { color: '#1E293B' },
    editedText: { fontSize: 10, marginTop: 2 },
    mediaImage: { width: 200, height: 200, borderRadius: 8, backgroundColor: '#E2E8F0' },
    msgFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', marginTop: 4, marginHorizontal: 4 },
    timeText: { fontSize: 10, color: '#94A3B8' },

    inputContainer: { flexDirection: 'row', padding: 12, backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#F1F5F9', alignItems: 'flex-end' },
    attachBtn: { padding: 10, justifyContent: 'center', alignItems: 'center' },
    cancelEditBtn: { padding: 10, justifyContent: 'center', alignItems: 'center' },
    input: { flex: 1, backgroundColor: '#F1F5F9', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, paddingTop: 10, maxHeight: 100, fontSize: 15, borderWidth: 1, borderColor: '#E2E8F0', color: '#1E293B' },
    sendBtn: { backgroundColor: '#2563EB', width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', marginLeft: 8 },

    actionBar: { flexDirection: 'row', padding: 12, backgroundColor: '#E2E8F0', alignItems: 'center' },
    actionBtn: { padding: 12 },

    userCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, elevation: 2 },
    conversedCard: { backgroundColor: '#FFFFFF' },
    unconversedCard: { backgroundColor: '#F1F5F9' },
    avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#94A3B8', justifyContent: 'center', alignItems: 'center', marginRight: 16 },
    userInfo: { flex: 1 },
    userName: { fontSize: 16, fontWeight: 'bold', color: '#1E293B' },
    userRole: { fontSize: 13, color: '#64748B', marginTop: 2 },
    activeDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#10B981', marginRight: 4 },
    emptyText: { textAlign: 'center', color: '#94A3B8', marginTop: 40, fontStyle: 'italic' },

    modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.9)', justifyContent: 'center', alignItems: 'center' },
    closeModal: { position: 'absolute', top: 40, right: 20, zIndex: 10, padding: 10 },
    fullImage: { width: '100%', height: '80%' }
});
