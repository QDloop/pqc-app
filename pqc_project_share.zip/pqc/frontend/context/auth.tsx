import React from 'react';
import { useStorageState } from './useStorageState';

const AuthContext = React.createContext<{
    signIn: (token: string, role: string, user: any) => void;
    signOut: () => void;
    session?: string | null;
    role?: string | null;
    user?: any | null;
    isLoading: boolean;
}>({
    signIn: () => null,
    signOut: () => null,
    session: null,
    role: null,
    user: null,
    isLoading: false,
});

// This hook can be used to access the user info.
export function useSession() {
    const value = React.useContext(AuthContext);
    if (process.env.NODE_ENV !== 'production') {
        if (!value) {
            throw new Error('useSession must be wrapped in a <SessionProvider />');
        }
    }

    return value;
}

export function SessionProvider(props: React.PropsWithChildren) {
    const [[isLoading, session], setSession] = useStorageState('session');
    const [[isLoadingRole, role], setRole] = useStorageState('role');
    const [[isLoadingUser, userString], setUserString] = useStorageState('user');

    const user = userString ? JSON.parse(userString) : null;

    return (
        <AuthContext.Provider
            value={{
                signIn: (token, role, userData) => {
                    setSession(token);
                    setRole(role);
                    setUserString(JSON.stringify(userData));
                },
                signOut: () => {
                    setSession(null);
                    setRole(null);
                    setUserString(null);
                },
                session,
                role,
                user,
                isLoading,
            }}>
            {props.children}
        </AuthContext.Provider>
    );
}
