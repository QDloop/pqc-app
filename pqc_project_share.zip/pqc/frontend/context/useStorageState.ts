import * as React from 'react';

type UseStateHook<T> = [[boolean, T | null], (value: T | null) => void];

export function useStorageState(key: string): UseStateHook<string> {
    const [state, setState] = React.useState<[boolean, string | null]>([false, null]);

    const setValue = React.useCallback(
        (value: string | null) => {
            setState([false, value]);
        },
        []
    );

    return [state, setValue];
}
