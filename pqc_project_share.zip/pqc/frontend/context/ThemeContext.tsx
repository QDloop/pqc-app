import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const Themes = {
    light: { background: '#F8FAFC', card: '#FFFFFF', text: '#1E293B', primary: '#2563EB', secondary: '#64748B', border: '#E2E8F0', danger: '#EF4444', success: '#10B981', inactive: '#94A3B8' },
    dark: { background: '#0F172A', card: '#1E293B', text: '#F8FAFC', primary: '#38BDF8', secondary: '#94A3B8', border: '#334155', danger: '#F87171', success: '#34D399', inactive: '#475569' },
    eye_comfort: { background: '#FAF8F5', card: '#FFFDF9', text: '#433422', primary: '#D97706', secondary: '#A58B71', border: '#EAE1D3', danger: '#DC2626', success: '#059669', inactive: '#D1C2A5' },
    cyan: { background: '#083344', card: '#164E63', text: '#ECFEFF', primary: '#22D3EE', secondary: '#A5F3FC', border: '#0F766E', danger: '#FDA4AF', success: '#6EE7B7', inactive: '#155E75' }
};

export type ThemeType = keyof typeof Themes;

const ThemeContext = createContext<{ themeName: ThemeType, theme: typeof Themes['light'], setTheme: (t: ThemeType) => void }>({
    themeName: 'light',
    theme: Themes.light,
    setTheme: () => { }
});

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }: any) => {
    const [themeName, setThemeName] = useState<ThemeType>('light');

    useEffect(() => {
        AsyncStorage.getItem('app_theme').then(t => {
            // Handle legacy dark mode boolean migration
            if (t === 'true') { setTheme('dark'); }
            else if (t === 'false') { setTheme('light'); }
            else if (t && Themes[t as ThemeType]) { setThemeName(t as ThemeType); }
        })
    }, []);

    const setTheme = (t: ThemeType) => {
        setThemeName(t);
        AsyncStorage.setItem('app_theme', t);
    };

    return (
        <ThemeContext.Provider value={{ themeName, theme: Themes[themeName], setTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};
