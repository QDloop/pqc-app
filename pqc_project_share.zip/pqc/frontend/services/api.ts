import { Platform } from 'react-native';

const API_URL = 'http://192.168.0.114:5000'; // Change this IP if using USB Tethering (check ipconfig)

export const api = {
    login: async (credentials: any) => {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(credentials),
        });
        return response.json();
    },

    getLocks: async (token: string) => {
        const response = await fetch(`${API_URL}/locks`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getUsers: async (token: string) => {
        const response = await fetch(`${API_URL}/users`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    unlock: async (token: string, lockId: string, passwordVerify: string) => {
        // In real app, re-verify password with backend or derive key
        const response = await fetch(`${API_URL}/unlock`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ lock_id: lockId, verification: passwordVerify }),
        });
        return response.json();
    },

    getLogs: async (token: string) => {
        const response = await fetch(`${API_URL}/logs`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getLockStatus: async (token: string) => {
        const response = await fetch(`${API_URL}/lock-status`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getStats: async (token: string) => {
        const response = await fetch(`${API_URL}/stats`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    changePassword: async (token: string, oldPassword: string, newPassword: string) => {
        const response = await fetch(`${API_URL}/change-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ oldPassword, newPassword }),
        });
        return response.json();
    },

    registerUser: async (token: string, userData: any) => {
        const response = await fetch(`${API_URL}/register-user`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify(userData),
        });
        return response.json();
    },

    registerLock: async (lockData: any) => {
        const response = await fetch(`${API_URL}/register-lock`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(lockData),
        });
        return response.json();
    },

    approveLock: async (token: string, lockId: string) => {
        const response = await fetch(`${API_URL}/approve-lock/${lockId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
        });
        return response.json();
    },

    assignPermission: async (token: string, userId: string, lockId: string) => {
        const response = await fetch(`${API_URL}/assign-permission`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ user_id: userId, lock_id: lockId }),
        });
        return response.json();
    },

    relock: async (token: string, lockId: string) => {
        const response = await fetch(`${API_URL}/relock`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ lock_id: lockId }),
        });
        return response.json();
    },

    requestSignup: async (email: string) => {
        const response = await fetch(`${API_URL}/request-signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email }),
        });
        return response.json();
    },

    verifySignup: async (userData: any) => {
        const response = await fetch(`${API_URL}/verify-signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData),
        });
        return response.json();
    },

    getPendingUsers: async (token: string) => {
        const response = await fetch(`${API_URL}/pending-users`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getMyActivity: async (token: string) => {
        const response = await fetch(`${API_URL}/my-activity`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getMyStats: async (token: string) => {
        const response = await fetch(`${API_URL}/my-stats`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getSystemHealth: async (token: string) => {
        const response = await fetch(`${API_URL}/system-health`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getChatUsers: async (token: string) => {
        const response = await fetch(`${API_URL}/chat/users`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getMessages: async (token: string, receiverId: string) => {
        const response = await fetch(`${API_URL}/chat/messages?receiver_id=${receiverId}`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    getUnreadCount: async (token: string) => {
        const response = await fetch(`${API_URL}/chat/unread`, {
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    sendMessage: async (token: string, receiverId: string, content: string, type: string = 'text') => {
        const response = await fetch(`${API_URL}/chat/messages`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ receiver_id: receiverId, content, type }),
        });
        return response.json();
    },

    approveUser: async (token: string, userId: string) => {
        const response = await fetch(`${API_URL}/approve-user/${userId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
        });
        return response.json();
    },

    declineUser: async (token: string, userId: string) => {
        const response = await fetch(`${API_URL}/decline-user/${userId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
        });
        return response.json();
    },

    editMessage: async (token: string, msgId: string, content: string) => {
        const response = await fetch(`${API_URL}/chat/messages/${msgId}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ content }),
        });
        return response.json();
    },

    deleteMessage: async (token: string, msgId: string) => {
        const response = await fetch(`${API_URL}/chat/messages/${msgId}`, {
            method: 'DELETE',
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    recoverMessage: async (token: string, msgId: string) => {
        const response = await fetch(`${API_URL}/chat/messages/${msgId}/recover`, {
            method: 'POST',
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    markRead: async (token: string, roomId: string) => {
        const response = await fetch(`${API_URL}/chat/read`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ room_id: roomId }),
        });
        return response.json();
    },

    ping: async (token: string) => {
        const response = await fetch(`${API_URL}/ping`, {
            method: 'POST',
            headers: { 'Authorization': token },
        });
        return response.json();
    },

    updateProfilePic: async (token: string, profilePic: string) => {
        const response = await fetch(`${API_URL}/profile-pic`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': token },
            body: JSON.stringify({ profile_pic: profilePic }),
        });
        return response.json();
    }
};
