# kem init
